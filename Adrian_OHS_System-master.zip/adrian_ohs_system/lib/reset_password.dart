import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/login_page.dart';
import 'package:http/http.dart'as http;
import 'package:toast/toast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class reset extends StatefulWidget {
  @override
  _resetState createState() => _resetState();
}

class _resetState extends State<reset> {
  TextEditingController _otp = TextEditingController();

  TextEditingController _password_controller = TextEditingController();

  bool _isLoading = false;
  reset_password (String code, String Password) async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var jsonData = null;
    Map data =
    {
      'code': code,
      'password':Password
    };
    var response = await http.post("http://138.197.108.96:4000/auth/verify",body:data);
    if (response.statusCode == 200)
    {
      jsonData = json.decode(response.body);
      if(jsonData['ok'] == true){
        setState(() {
          _isLoading = false;
          sharedPreferences.setString('token', jsonData['token']);
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context)=> login()), (Route <dynamic> route)=> false);
        });
      }else{
        Toast.show("Wrong otp", context);
      }
    }
    else
    {
      print(response.body);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      backgroundColor: Colors.white,
      body:  Wrap(
        children: <Widget>[
          Stack(
            children: <Widget>[
              ClipRRect(
                borderRadius:
                BorderRadius.only(bottomRight: Radius.circular(220.0)),
                child: Container(
                  color: Color(0xffe92759),
                  height: 70.0,
                  width: 130.0,
                ),
              ),
              Positioned(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(400.0),
                          bottomRight: Radius.circular(500.0)),
                      child: Container(
                        color: Color(0xff141fac),
                        height: 130.0,
                        width: 60.0,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      SizedBox(height: 30.0),
                      Container(
                        child: Image(image: new AssetImage("assets/adrian-loader.gif")),
                        margin: const EdgeInsets.all(10.0),
                        width: 200.0,
                        height: 200.0,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Reset Password',
                        style: TextStyle(
                            fontSize: 25.0, color: Color(0xffe92759)),
                      )
                    ],
                  ),
                  SingleChildScrollView(
                    child: Padding(
                      padding:
                      EdgeInsets.only(left: 28.0, right: 28.0, top: 25.0),
                      child: Column(
                        children: <Widget>[
                          Container(
                            width: double.infinity,
                            height: 200,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8.0),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black12,
                                      offset: Offset(0.0, 15.0),
                                      blurRadius: 15.0),
                                  BoxShadow(
                                      color: Colors.black12,
                                      offset: Offset(0.0, -10.0),
                                      blurRadius: 10.0)
                                ]),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: 16.0, right: 16.0, top: 16.0),
                              child: Column(
                                children: <Widget>[
                                  TextField(
                                    keyboardType: TextInputType.number,
                                    controller: _otp,
                                    decoration: InputDecoration(
                                      labelText: 'Enter OTP',
                                      labelStyle:
                                      TextStyle(color: Colors.grey[500]),
                                      border: UnderlineInputBorder(
                                        borderSide: BorderSide.none,
                                      ),
                                      icon: Icon(
                                        Icons.confirmation_number,
                                        color: Color(0xffe92759),
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                  Divider(
                                    color: Colors.grey,
                                  ),
                                  TextField(
                                    controller: _password_controller,
                                    decoration: InputDecoration(
                                        labelText: 'Enter New Password',
                                        labelStyle:
                                        TextStyle(color: Colors.grey[500]),
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide.none,
                                        ),
                                        icon: Icon(
                                          Icons.lock,
                                          color: Color(0xffe92759),
                                          size: 20,
                                        )),
                                    obscureText: true,
                                  ),
                                  Divider(
                                    color: Colors.grey,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 20.0,
                          ),
                          ButtonTheme(
                              minWidth: 150.0,
                              child: RaisedButton(
                                padding: const EdgeInsets.all(9.0),
                                onPressed: () async {
                                  _isLoading = true;
                                  reset_password(_otp.text, _password_controller.text);
                                },
                                color: Color(0xff141fac),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0)),
                                child: new Text(
                                  "Submit",
                                  style: TextStyle(
                                      fontSize: 20, color: Colors.white),
                                ),
                              )),
                          SizedBox(
                            height: 20.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
