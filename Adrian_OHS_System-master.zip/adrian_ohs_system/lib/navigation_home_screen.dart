import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/accepted_jobs.dart';
import 'package:adrian_ohs_app/in_progress_jobs.dart';
import 'package:adrian_ohs_app/rejected_jobs.dart';
import 'completed_jobs.dart';
import 'home_page.dart';
import 'jobs_pending_ohs.dart';
import 'res/ui/app_theme.dart';
import 'res/ui/custom_drawer/drawer_user_controller.dart';
import 'res/ui/custom_drawer/menu_drawer.dart';

class NavigationHomeScreen extends StatefulWidget {
  const NavigationHomeScreen({Key key}) : super(key: key);
  @override
  _NavigationHomeScreenState createState() => _NavigationHomeScreenState();
}

class _NavigationHomeScreenState extends State<NavigationHomeScreen> {
  Widget screenView;
  DrawerIndex drawerIndex;
  AnimationController sliderAnimationController;

  @override
  void initState() {
    drawerIndex = DrawerIndex.homePageNNewJobs;
    screenView = const HomePage();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return new WillPopScope(
      onWillPop: onWillPop,
      child: Container(
        color: AppTheme.nearlyWhite,
        child: SafeArea(
          top: false,
          bottom: false,
          child: Scaffold(
            backgroundColor: AppTheme.nearlyWhite,
            body: DrawerUserController(
              screenIndex: drawerIndex,
              drawerWidth: MediaQuery.of(context).size.width * 0.75,
              animationController: (AnimationController animationController) {
                sliderAnimationController = animationController;
              },
              onDrawerCall: (DrawerIndex drawerIndexdata) {
                changeIndex(drawerIndexdata);
              },
              screenView: screenView,
            ),
          ),
        ),
      ),
    );
  }

  void changeIndex(DrawerIndex drawerIndexData) {
    if (drawerIndex != drawerIndexData) {
      drawerIndex = drawerIndexData;
      if (drawerIndex == DrawerIndex.homePageNNewJobs) {
        setState(() {
          screenView = const NavigationHomeScreen();
        });
      }
      else if (drawerIndex == DrawerIndex.pendingJobs) {
        setState(() {
          screenView = const JobsPendingOHS();
        });
      }
      else if (drawerIndex == DrawerIndex.acceptedJobs) {
        setState(() {
          screenView = const AcceptedJobs();
        });
      }
      else if (drawerIndex == DrawerIndex.rejectedJobs) {
        setState(() {
          screenView = const RejectedJobs();
        });
      }
      else if (drawerIndex == DrawerIndex.jobsInProgress) {
        setState(() {
          screenView = const InProgressJobs();
        });
      } else if (drawerIndex == DrawerIndex.completedCompleted) {
        setState(() {
          screenView = CompleteJobs();
        });
      } else {
        //do in your way......
      }
    }
  }

  Future<bool> onWillPop() {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => NavigationHomeScreen()),
//                        builder: (context) => CardInfoScreen(jobId: currentPage.round().toString())),
    );
  }
}
