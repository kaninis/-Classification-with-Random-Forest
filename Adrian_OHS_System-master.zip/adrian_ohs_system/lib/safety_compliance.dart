
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:dio/dio.dart';
import 'package:exif/exif.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:adrian_ohs_app/res/graphql/graphQLMutations.dart';
import 'package:adrian_ohs_app/res/graphql/graphqlConf.dart';
import 'package:adrian_ohs_app/res/model/model_documents.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:geolocator/geolocator.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:toast/toast.dart';
import 'res/model/model_hazards.dart';
import 'home_page.dart';
import 'navigation_home_screen.dart';
import 'res/ui/app_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io' as Io;
import 'package:location/location.dart' as  loc;
class safetyCompliance extends StatefulWidget {
  final String jobId;

  const safetyCompliance({Key key, @required this.jobId}) : super(key: key);

  @override
  _safetyComplianceState createState() => _safetyComplianceState(JobId: jobId);
}

class _safetyComplianceState extends State<safetyCompliance> {
  String token;
  Position position;
  var currentLocation;
  var location = new loc.Location();
  void getCurrentLocation()
  async{
    currentLocation = (await location.getLocation());
  position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  print(position);
  }



  List<String> hazard_id = [];
  List<String> document_id =[];
  final String JobId;
  String hazard, document;
  Color hazard_color = AppTheme.mainPink;

  final String url = "http://158.101.165.50/upload";
  File ppe, induction, toolboxtalk, emergency, first_aid_kit, fire_extinguisher;
  String ppeURL,first_aid_kitURL,fire_extinguisherURL, inductionURL, toolboxtalkURL, emergencyURL;
  var image, file;

  TextEditingController controller = new TextEditingController();

  _safetyComplianceState({Key key, @required this.JobId});
  Future<String> uploadPhoto(File _image, String _path, String type, String Metadata) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    token = sharedPreferences.getString("token");
    print(_path);
    Dio dio = new Dio();
    FormData _formdata = new FormData();
    _formdata.add("file", new UploadFileInfo(_image, _path));
    _formdata.add("datetime", Metadata);
    final response = await dio.post(
      'http://158.101.165.50/upload',
      data: _formdata,
      options: Options(
        method: 'POST',
        headers: {
          "authorization": "$token",
        },
        responseType: ResponseType.json,
      ),
    );
    if (response.statusCode == 200 || response.statusCode == 500) {
      var jsonData = json.decode(response.toString());
      String ImageFileURL = jsonData["url"];
      print("ImageURL: " + ImageFileURL);
      if (type == "ppe") {
        ppeURL = ImageFileURL;
      }else if (type == "first_aid_kit") {
        first_aid_kitURL = ImageFileURL;
      }else if (type == "fire_extinguisher") {
        fire_extinguisherURL = ImageFileURL;
      } else if (type == "induction") {
        inductionURL = ImageFileURL;
      } else if (type == "toolboxtalk") {
        toolboxtalkURL = ImageFileURL;
      } else if (type == "emergency") {
        emergencyURL = ImageFileURL;
      }
//      return ImageURL;
    } else {
      throw Exception('Failed to upload!');
    }
  }

  final _controller = new PageController();
  static const _kDuration = const Duration(milliseconds: 300);
  static const _kCurve = Curves.ease;

  saveSafetyCompliance() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    List<String> hazards = sharedPreferences.getStringList('hazards');
    List <String>documents = sharedPreferences.getStringList('documents');
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document: queryMutation.updateSafetyCompliance(
            ppeURL,first_aid_kitURL,fire_extinguisherURL, inductionURL,toolboxtalkURL, emergencyURL, hazards, documents, JobId),
      ),
    );
    if (result.hasException) {
      Toast.show("Safety data has errors", context);
    } else {
      Toast.show("Safety updated", context);
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => new NavigationHomeScreen()));
    }
    return true;
  }

  List<documents> listDocuments = List<documents>();
  List<hazards> listHazards = List<hazards>();
  List<bool> inputs = new List<bool>();
  List<bool> document_inputs = new List<bool>();
  int item_count;

  void ItemChange(bool val, int index) {
    setState(() {
      inputs[index] = val;
    });
  }
  void documentSelect(bool val, int index) {
    setState(() {
      document_inputs[index] = val;
    });
  }

  void fillDocumentList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getAllDocuments(),
      ),
    );
    if (!graphQueryResult.hasException) {
      for (var i = 0; i < graphQueryResult.data["documents"].length; i++) {
        setState(() {
          listDocuments.add(
            documents(
              graphQueryResult.data["documents"][i]["id"],
              graphQueryResult.data["documents"][i]["name"],
              graphQueryResult.data["documents"][i]["url"],
            ),
          );
        });
      }
    }
  }

  void fillHazardList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getHazards(),
      ),
    );
    if (!graphQueryResult.hasException) {
      for (var i = 0; i < graphQueryResult.data["hazards"].length; i++) {
        setState(() {
          listHazards.add(
            hazards(
              graphQueryResult.data["hazards"][i]["id"],
              graphQueryResult.data["hazards"][i]["text"],
              graphQueryResult.data["hazards"][i]["consequence"],
//              graphQueryResult.data["hazards"][i]["controls"]["text"],
            ),
          );
        });
      }

      print(listHazards.length.toString());
    }
    item_count = graphQueryResult.data["hazards"].length;
  }

  @override
  initState() {
    getCurrentLocation();
    fillDocumentList();
    fillHazardList();
    setState(() {
      for (int i = 0; i < 20; i++) {
        inputs.add(false);
        document_inputs.add(false);
      }
    });
    print ("location:$currentLocation");
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> _assessmentSteps = [
      Container(
          height: MediaQuery.of(context).size.height - 400,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(
                  height: MediaQuery.of(context).size.height - 200,
                  child: SingleChildScrollView(
                    child: Column(
                      children: <Widget>[
                        Card(
                          child: ExpansionTile(
                            title: Text(
                              "Personnel PPE Photos",
                            ),
                            children: <Widget>[
                              Container(
                                child: ppe == null
                                    ? Container(
                                        width: 180.0,
                                        height: 270.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Center(
                                            child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              'No image',
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              "Click attachment icon to select from gallery or the camera icon to take a photo",
                                              style:
                                                  TextStyle(color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            )
                                          ],
                                        )),
                                      )
                                    : Container(
                                        width: 160.0,
                                        height: 240.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Image.file(
                                          ppe,
                                          height: 150.0,
                                          width: 100.0,
                                        ),
                                      ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
//                                  IconButton(
//                                    icon: Icon(Icons.attach_file),
//                                    tooltip: 'attach image file',
//                                    onPressed: () async {
//                                      image = await ImagePicker.pickImage(
//                                          source: ImageSource.gallery);
//                                      var bytes = await image.readAsBytes();
//                                      var tags = await readExifFromBytes(bytes);
//                                      String ppeMetadata = tags['Image DateTime'].toString();
////                                      print(tags['Image DateTime']);
////                                      print(tags['Lat']);
////                                      print(tags['Long']);
//                                      print("Camera Imagege: $ppeMetadata");
//                                      setState(() {
//                                        ppe = image;
//                                        uploadPhoto(image,
//                                            image.uri.toFilePath(), "ppe",ppeMetadata);
//                                        print(ppeMetadata);
//                                      });
//                                    },
//                                  ),
                                  ButtonTheme(
                                      minWidth: 70.0,
                                      child: RaisedButton(
                                        padding: const EdgeInsets.all(9.0),
                                        onPressed: () async {
                                          image = await ImagePicker.pickImage(
                                              source: ImageSource.camera,
                                              maxWidth: 480,
                                              maxHeight: 600);
                                          var bytes = await image.readAsBytes();
                                          var tags = await readExifFromBytes(bytes);
                                          print(tags);
                                          String ppeMetadata = tags['Image DateTime'].toString();
                                          setState(() {
                                            ppe = image;
                                            uploadPhoto(image,
                                                image.uri.toFilePath(), "ppe", ppeMetadata);
                                          });
                                        },
                                        color: Color(0xffe92759),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20.0)),
                                        child: Icon(
                                          Icons.camera_alt,
                                          color: AppTheme.white,
                                        ),
                                      )),
                                  Spacer(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Card(
                          child: ExpansionTile(
                            title: Text(
                              "First aid Kit",
                            ),
                            children: <Widget>[
                              Container(
                                child: first_aid_kit == null
                                    ? Container(
                                        width: 180.0,
                                        height: 270.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Center(
                                            child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              'No image',
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              "Click attachment icon to select from gallery or the camera icon to take a photo",
                                              style:
                                                  TextStyle(color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            )
                                          ],
                                        )),
                                      )
                                    : Container(
                                        width: 160.0,
                                        height: 240.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Image.file(
                                          first_aid_kit,
                                          height: 150.0,
                                          width: 100.0,
                                        ),
                                      ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
//                                  IconButton(
//                                    icon: Icon(Icons.attach_file),
//                                    tooltip: 'attach image',
//                                    onPressed: () async {
//                                      image = await ImagePicker.pickImage(
//                                          source: ImageSource.gallery);
//                                      var bytes = await image.readAsBytes();
//                                      var tags = await readExifFromBytes(bytes);
//                                      String ppeMetadata = tags['Image DateTime'].toString();
//                                      setState(() {
//                                        first_aid_kit = image;
//                                        uploadPhoto(image,
//                                            image.uri.toFilePath(), "first_aid_kit", ppeMetadata);
//                                      });
//                                    },
//                                  ),
                                  ButtonTheme(
                                      minWidth: 70.0,
                                      child: RaisedButton(
                                        padding: const EdgeInsets.all(9.0),
                                        onPressed: () async {
                                          image = await ImagePicker.pickImage(
                                              source: ImageSource.camera,
                                              maxWidth: 480,
                                              maxHeight: 600);
                                          var bytes = await image.readAsBytes();
                                          var tags = await readExifFromBytes(bytes);
                                          String ppeMetadata = tags['Image DateTime'].toString();
                                          setState(() {
                                            first_aid_kit = image;
                                            uploadPhoto(image,
                                                image.uri.toFilePath(), "first_aid_kit", ppeMetadata);
                                          });
                                          Toast.show(ppeMetadata, context);
                                        },
                                        color: Color(0xffe92759),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20.0)),
                                        child: Icon(
                                          Icons.camera_alt,
                                          color: AppTheme.white,
                                        ),
                                      )),
                                  Spacer(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Card(
                          child: ExpansionTile(
                            title: Text("Fire Extinguisher"),
                            children: <Widget>[
                              Container(
                                child: fire_extinguisher == null
                                    ? Container(
                                        width: 180.0,
                                        height: 270.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Center(
                                            child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              'No image',
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              "Click attachment icon to select from gallery or the camera icon to take a photo",
                                              style:
                                                  TextStyle(color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            )
                                          ],
                                        )),
                                      )
                                    : Container(
                                        width: 160.0,
                                        height: 240.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Image.file(
                                          fire_extinguisher,
                                          height: 150.0,
                                          width: 100.0,
                                        ),
                                      ),

                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
//                                  IconButton(
//                                    icon: Icon(Icons.attach_file),
//                                    tooltip: 'Increase volume by 10',
//                                    onPressed: () async {
//                                      image = await ImagePicker.pickImage(
//                                          source: ImageSource.gallery);
//                                      var bytes = await image.readAsBytes();
//                                      var tags = await readExifFromBytes(bytes);
//                                      String ppeMetadata = tags['Image DateTime'].toString();
//                                      setState(() {
//                                        fire_extinguisher = image;
//                                        uploadPhoto(image,
//                                            image.uri.toFilePath(), "fire_extinguisher",ppeMetadata);
//                                      });
//                                    },
//                                  ),
                                  ButtonTheme(
                                      minWidth: 70.0,
                                      child: RaisedButton(
                                        padding: const EdgeInsets.all(9.0),
                                        onPressed: () async {
                                          image = await ImagePicker.pickImage(
                                              source: ImageSource.camera,
                                              maxWidth: 480,
                                              maxHeight: 600);
                                          var bytes = await image.readAsBytes();
                                          var tags = await readExifFromBytes(bytes);
                                          String ppeMetadata = tags['Image DateTime'].toString();
                                          setState(() {
                                            fire_extinguisher = image;
                                            uploadPhoto(image,
                                                image.uri.toFilePath(), "fire_extinguisher", ppeMetadata);
                                          });
                                        },
                                        color: Color(0xffe92759),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20.0)),
                                        child: Icon(
                                          Icons.camera_alt,
                                          color: AppTheme.white,
                                        ),
                                      )),
                                  Spacer(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Card(
                          child: ExpansionTile(
                            title: Text(
                              "Induction Form Image Upload",
                            ),
                            children: <Widget>[
                              Container(
                                child: induction == null
                                    ? Container(
                                        width: 180.0,
                                        height: 270.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Center(
                                            child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              'No image',
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              "Click attachment icon to select from gallery or the camera icon to take a photo",
                                              style:
                                                  TextStyle(color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            )
                                          ],
                                        )),
                                      )
                                    : Container(
                                        width: 160.0,
                                        height: 240.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color:Colors.white,
                                        ),
                                        child: Image.file(
                                          induction,
                                          height: 150.0,
                                          width: 100.0,
                                        ),
                                      ),
                              ),
                              SizedBox(
                                height: 30.0,
                              ),
                              Row(
                                children: <Widget>[
//                                  IconButton(
//                                    icon: Icon(Icons.attach_file),
//                                    tooltip: 'Attach image',
//                                    onPressed: () async {
//                                      image = await ImagePicker.pickImage(
//                                          source: ImageSource.gallery);
//                                      var bytes = await image.readAsBytes();
//                                      var tags = await readExifFromBytes(bytes);
//                                      String ppeMetadata = tags['Image DateTime'].toString();
//                                      setState(() {
//                                        induction = image;
//                                        uploadPhoto(
//                                            image,
//                                            image.uri.toFilePath(),
//                                            "induction", ppeMetadata);
//                                      });
//                                    },
//                                  ),
                                  ButtonTheme(
                                      minWidth: 70.0,
                                      child: RaisedButton(
                                        padding: const EdgeInsets.all(9.0),
                                        onPressed: () async {
                                          image = await ImagePicker.pickImage(
                                              source: ImageSource.camera,
                                              maxWidth: 480,
                                              maxHeight: 600);
                                          var bytes = await image.readAsBytes();
                                          var tags = await readExifFromBytes(bytes);
                                          String ppeMetadata = tags['Image DateTime'].toString();
                                          setState(() {
                                            induction = image;
                                            uploadPhoto(
                                                image,
                                                image.uri.toFilePath(),
                                                "induction", ppeMetadata);
                                          });
                                        },
                                        color: Color(0xffe92759),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20.0)),
                                        child: Icon(
                                          Icons.camera_alt,
                                          color: AppTheme.white,
                                        ),
                                      )),
                                  Spacer(),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Card(
                          child: ExpansionTile(
                            title: Text(
                              "Toolbox Talk Form Image Upload",
                            ),
                            children: <Widget>[
                              Container(
                                child: toolboxtalk == null
                                    ? Container(
                                        width: 180.0,
                                        height: 270.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Center(
                                            child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              'No image',
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            ),
                                            Text(
                                              "Click attachment icon to select from gallery or the camera icon to take a photo",
                                              style:
                                                  TextStyle(color: Colors.grey),
                                              textAlign: TextAlign.center,
                                            )
                                          ],
                                        )),
                                      )
                                    : Container(
                                        width: 160.0,
                                        height: 240.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: Colors.white,
                                        ),
                                        child: Image.file(
                                          toolboxtalk,
                                          height: 150.0,
                                          width: 100.0,
                                        ),
                                      ),
                              ),
                              SizedBox(
                                height: 30.0,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
//                                  IconButton(
//                                    icon: Icon(Icons.attach_file),
//                                    tooltip: 'Attach image',
//                                    onPressed: () async {
//                                      image = await ImagePicker.pickImage(
//                                          source: ImageSource.gallery);
//                                      var bytes = await image.readAsBytes();
//                                      var tags = await readExifFromBytes(bytes);
//                                      String ppeMetadata = tags['Image DateTime'].toString();
//                                      setState(() {
//                                        toolboxtalk = image;
//                                        uploadPhoto(
//                                            image,
//                                            image.uri.toFilePath(),
//                                            "toolboxtalk", ppeMetadata);
//                                      });
//                                    },
//                                  ),
                                  ButtonTheme(
                                      minWidth: 70.0,
                                      child: RaisedButton(
                                        padding: const EdgeInsets.all(9.0),
                                        onPressed: () async {
                                          image = await ImagePicker.pickImage(
                                              source: ImageSource.camera,
                                              maxWidth: 480,
                                              maxHeight: 600);
                                          var bytes = await image.readAsBytes();
                                          var tags = await readExifFromBytes(bytes);
                                          String ppeMetadata = tags['Image DateTime'].toString();
                                          setState(() {
                                            toolboxtalk = image;
                                            uploadPhoto(
                                                image,
                                                image.uri.toFilePath(),
                                                "toolboxtalk", ppeMetadata);
                                          });
                                        },
                                        color: Color(0xffe92759),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20.0)),
                                        child: Icon(
                                          Icons.camera_alt,
                                          color: AppTheme.white,
                                        ),
                                      )),
                                  Spacer(),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                ButtonTheme(
                    minWidth: 150.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        if (ppe == null)
                        {
                          Toast.show("Attach Personnell Photos", context);
                        }
                        else if (first_aid_kit == null)
                        {
                          Toast.show("Attach First Aid Kit Photo", context);
                        }
                        else if (fire_extinguisher == null)
                        {
                          Toast.show("Attach Fire Extinguisher Photo", context);
                        }
                        else if (toolboxtalk == null)
                        {
                          Toast.show("Attach Toolbox Talk Form Image", context);
                        }
                        else if (induction == null)
                        {
                          Toast.show("Attach Induction Form Image", context);
                        }else {
                          _controller.nextPage(
                              duration: _kDuration, curve: _kCurve);
                        }
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.white,
                      ),
                    )),
              ],
            ),
          )
      ),
      Container(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Text("Job Hazard Analysis",
                    style: TextStyle(
                      color: AppTheme.mainPink,
                      fontSize: 26.0,
                      fontFamily: "Calibre-Semibold",
                      letterSpacing: 1.0,
                    )),
                Container(
                  height:MediaQuery.of(context).size.height-400,
                  child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemCount: listHazards.length,
                    itemBuilder: (context, int index) {
                      return CheckboxListTile(
                        value: inputs[index],
                        onChanged: (bool value) async{
                          ItemChange(value, index);
                          hazard = listHazards[index].getJobHazard();
                          if(value == true) {
                            hazard_id.add("${listHazards[index].getJobId()}");
                          }
                          else
                            {
                              hazard_id = hazard_id.where((id) => id != "${listHazards[index].getJobId()}").toList();
                            }
                          SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();
                          sharedPreferences.setStringList('hazards', hazard_id);

                        },
                        selected: listHazards == null ? false : true,
                        title: Text(
                          "${listHazards[index].getJobHazard()}",
                        ),
                      );
                    },
                  ),
                ),
                ButtonTheme(
                    minWidth: 150.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        _controller.nextPage(
                            duration: _kDuration, curve: _kCurve);
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.white,
                      ),
                    )),
              ],
            ),
          )),
//      Container(
//          child: SingleChildScrollView(
//        child: Column(
//          children: <Widget>[
//            Text("Job Hazard Analysis",
//                style: TextStyle(
//                  color: AppTheme.mainPink,
//                  fontSize: 26.0,
//                  fontFamily: "Calibre-Semibold",
//                  letterSpacing: 1.0,
//                )),
//            Container(
//              height: 350,
//              child: ListView.builder(
//                scrollDirection: Axis.vertical,
//                shrinkWrap: true,
//                itemCount: listHazards.length,
//                itemBuilder: (context, int index) {
//                  return ExpansionTile(
//                    title: Text("${listHazards[index].getJobHazard()}",
//                        style: TextStyle(
//                          color: hazard_color,
//                          fontSize: 15.0,
//                          fontFamily: "Calibre-Semibold",
//                          letterSpacing: 1.0,
//                        )),
//                    children: <Widget>[
//                      SingleChildScrollView(
//                        child: Container(
//                            height: 200,
//                            child: ListView.builder(
//                                scrollDirection: Axis.vertical,
//                                shrinkWrap: true,
//                                itemCount: listHazards.length,
//                                itemBuilder: (context, index) {
//                                  return CheckboxListTile(
//                                    value: inputs[index],
//                                    onChanged: (bool value) {
//                                      ItemChange(value, index);
//                                      hazard =
//                                          listHazards[index].getConsequence();
//
//                                      if (value == true) {
//                                        Toast.show(
//                                            "${listHazards[index].getConsequence()}",
//                                            context);
//                                        hazard_color = Colors.black;
//                                      }
//                                    },
//                                    selected:
//                                        listHazards == null ? false : true,
//                                    title: Text(
//                                      "${listHazards[index].getConsequence()}",
//                                    ),
//                                  );
//                                })),
//                      ),
//                    ],
//                  );
////                        CheckboxListTile(
////                        value: inputs[index],
////                        onChanged: (bool value) {
////                          ItemChange(value, index);
////                          hazard = listHazards[index].getJobHazard();
////                          if(value == true) {
////                            Toast.show(
////                                "${listHazards[index].getJobHazard()}", context);
////                          }
////
////
////                        },
////                        selected: listHazards == null ? false : true,
////                        title: Text(
////                          "${listHazards[index].getJobHazard()}",
////                        ),
////                      );
//                },
//              ),
//            ),
//            ButtonTheme(
//                minWidth: 150.0,
//                child: RaisedButton(
//                  padding: const EdgeInsets.all(9.0),
//                  onPressed: () async {
//                    _controller.nextPage(duration: _kDuration, curve: _kCurve);
//                  },
//                  color: Color(0xff141fac),
//                  shape: RoundedRectangleBorder(
//                      borderRadius: BorderRadius.circular(20.0)),
//                  child: Icon(
//                    Icons.arrow_forward_ios,
//                    color: AppTheme.white,
//                  ),
//                )),
//          ],
//        ),
//      )),
      Container(
          child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text("Confirm that you Have Read the following Documents by checking the Box",
                style: TextStyle(
                  color: AppTheme.mainPink,
                  fontSize: 14.0,
                  fontFamily: "Calibre-Semibold",
                  letterSpacing: 1.0,
                )),
            Container(
              height: 350,
              child: ListView.builder(
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemCount: listDocuments.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child:Row(children: <Widget>[
                        Flexible(
                          child:CheckboxListTile(
                            value: document_inputs[index],
                            onChanged: (bool value) async{
                              documentSelect(value, index);
                              document = listDocuments[index].getDocumentName();

                              if (value == true) {
                                document_id.add("${listDocuments[index].getDocumentId()}");
                                hazard_color = Colors.black;
                              }else
                                {
                                  document_id = document_id.where((id) => id != "${listDocuments[index].getDocumentId()}").toList();
                                }
                              SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();
                              sharedPreferences.setStringList('documents', document_id);
                            },
                            selected: listDocuments == null ? false : true,
                            title: Text(
                              "${listDocuments[index].getDocumentName()}",
                            ),
                          ) ,
                        ),
                        IconButton(
                          icon: Icon(Icons.file_download),
                          tooltip: 'download document',
                          onPressed: () async{
                            document = await listDocuments[index].getDocumentUrl();
                            List<String> filename = document.split("?")[0].split("/");
                              await FlutterDownloader.enqueue(
                                url: document,
                                fileName: filename[7].replaceAll("%20", " "),
                                savedDir: '/storage/emulated/0/Documents',
                                showNotification: true, // show download progress in status bar (for Android)
                                openFileFromNotification: true, // click on notification to open downloaded file (for Android)
                              );
                              print(document);
                              print(filename);
                          },
                        ),

                      ],),
                    );
                  }),
            ),
            RaisedButton(
                color: Color(0xffe92759),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0)),
                child: Text('Submit',
                    style: TextStyle(
                      color: AppTheme.white,
                      fontSize: 20.0,
                      fontFamily: "Calibre-Semibold",
                      letterSpacing: 1.0,
                    )),
                onPressed: () async {
                  saveSafetyCompliance();
                }),
          ],
        ),
      )),
    ];
    return Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: <Widget>[
              Container(
                width: double.maxFinite,
                height: MediaQuery.of(context).size.height,
                child: Stack(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                      ),
                      child: Container(
                        height: MediaQuery.of(context).size.height/2,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [
                                  Color(0xffe92759),
                                  Color(0xFF141FAC),
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                tileMode: TileMode.clamp)
                        ),
                      ),
                    ),
                    Positioned(
                      top: 70,
                      left: 20,
                      child: Text(
                        'Safety Compliance Assessment',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,

                        ),
                      ),
                    ),
                    Positioned(
                      top: 100,
                      child: Container(
                        padding: EdgeInsets.all(32),
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(62),
                                topRight: Radius.circular(62))),
                        child: Column(
                          children: <Widget>[
                            Flexible(
                              child: PageView.builder(
                                controller: _controller,
                                itemCount: _assessmentSteps.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return _assessmentSteps[
                                      index % _assessmentSteps.length];
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}
