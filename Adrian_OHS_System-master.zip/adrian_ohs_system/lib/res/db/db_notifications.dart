import 'dart:async';
import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../model/model_notification.dart';


class DBProviderNotifications {
  DBProviderNotifications._();

  static final DBProviderNotifications dbNotifications = DBProviderNotifications._();

  Database _databaseNotification;

  Future<Database> get database async {
    if (_databaseNotification != null) return _databaseNotification;
    // if _databaseSyncController is null we instantiate it
    _databaseNotification = await initDB();
    return _databaseNotification;
  }

  initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "notifications.db");
    return await openDatabase(path, version: 1, onOpen: (db) {},
        onCreate: (Database db, int version) async {
      await db.execute("CREATE TABLE Notifications ("
          "id INTEGER PRIMARY KEY,"
          "uid TEXT UNIQUE,"
          "title TEXT,"
          "body TEXT,"
          "notified_at_date TEXT"
          ")");
    });
  }

  newNotification(NotificationModel newNotification) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM Notifications");
    int id = table.first["id"];
    var raw;

    var res = await db.query("Notifications",
        where: "uid = ?",
        whereArgs: [newNotification.uid]);

    if (res.isEmpty) {
      //insert to the table using the new id
      raw = await db.rawInsert(
          "INSERT Into Notifications (id,uid,title,body,notified_at_date)"
              " VALUES (?,?,?,?,?)",
          [
            id,
            newNotification.uid,
            newNotification.title,
            newNotification.body,
            newNotification.notifiedAtDate
          ]);
      print("Notification Saved");
    }
//    userContactExists = null;
    return raw;
  }

  updateNotification(NotificationModel newNotificationSync, int id) async {
    final db = await database;
    var res = await db.update("Notifications", newNotificationSync.toMap(),
        where: "id = ?", whereArgs: [newNotificationSync.id]);
    return res;
  }

  getNotification(String dateToday) async {
    final db = await database;
    var res = await db.query("Notifications",
        where: "last_sync_date = ?", whereArgs: [dateToday]);
    return res.isNotEmpty ? NotificationModel.fromMap(res.first) : null;
  }

  Future<List<NotificationModel>> getAllNotifications() async {
    final db = await database;
    var res = await db.query("Notifications", orderBy: "id DESC");
    List<NotificationModel> list =
    res.isNotEmpty ? res.map((c) => NotificationModel.fromMap(c)).toList() : [];
    return list;
  }

  deleteNotification(int id) async {
    final db = await database;
    return db.delete("Notifications", where: "id = ?", whereArgs: [id]);
  }

  deleteAllSync() async {
    final db = await database;
    db.rawDelete("Delete * from Notifications");
  }
}
