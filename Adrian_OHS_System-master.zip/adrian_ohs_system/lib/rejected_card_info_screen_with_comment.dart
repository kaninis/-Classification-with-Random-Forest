import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/safety_compliance.dart';
import 'package:adrian_ohs_app/home_page.dart';
import 'package:adrian_ohs_app/res/graphql/graphQLMutations.dart';
import 'package:adrian_ohs_app/res/graphql/graphqlConf.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:toast/toast.dart';
import 'job_declining_ui.dart';
import 'navigation_home_screen.dart';
import 'res/ui/app_theme.dart';

class RejectedCardInfoScreen extends StatefulWidget {
  final Color color1;
  final Color color2;
  final Color color3;

  final String jobId;

  RejectedCardInfoScreen(
      {Key key,
      @required this.jobId,
      this.color1 = Colors.deepOrangeAccent,
      this.color2 = Colors.deepPurple,
      this.color3 = Colors.lightGreen})
      : super(key: key);
  @override
  _RejectedCardInfoScreenState createState() =>
      _RejectedCardInfoScreenState(JobId: jobId);
}

class _RejectedCardInfoScreenState extends State<RejectedCardInfoScreen>
    with TickerProviderStateMixin {
  final String JobId;
  HomePage homePage = HomePage();
  final double infoHeight = 364.0;
  AnimationController animationController;
  Animation<double> animation;
  double opacity1 = 0.0;
  double opacity2 = 0.0;
  double opacity3 = 0.0;

  var jobIdToRejectComments;

  String JobStatusId;
  String JobStatusType;
  String JobDepartment;
  String JobName;
//  String JobHazardRiskLevel;
  String JobScopeName;
//  String JobActivity,
  String
      induction,
      ppe,
      toolboxtalk,
      extinguisher,
      first_aid,
      Documents, location_name;
  String JobRejectionResponse1;


  var _result;

  _RejectedCardInfoScreenState({Key key, @required this.JobId});

  @override
  void initState() {
    animationController = AnimationController(
        duration: const Duration(milliseconds: 1000), vsync: this);
    animation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0, 1.0, curve: Curves.fastOutSlowIn)));
    setData();
    super.initState();
    getJobCardDetails(JobId).then((result1) {
      setState(() {
        _result = result1;
      });
    });

    print("JobId: " + JobId.toString());
    jobIdToRejectComments = JobId;
  }

  getJobCardDetails(String jobId) async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getASingleJobDetails(jobId),
      ),
    );
    if (!graphQueryResult.hasException) {
      JobName = graphQueryResult.data["job"]["name"];
      JobStatusId = graphQueryResult.data["job"]["status"]["id"];
      JobStatusType = graphQueryResult.data["job"]["status"]["type"];
      JobRejectionResponse1 = graphQueryResult.data["job"]["status"]["reason"];
      JobDepartment = graphQueryResult.data["job"]["scope"]["department"]["name"];
//      JobHazardRiskLevel = graphQueryResult.data["job"]["scope"]["hazard"];
      JobScopeName = graphQueryResult.data["job"]["scope"]["name"];
      location_name = graphQueryResult.data["job"]["location_name"];
//      JobActivity = graphQueryResult.data["job"]["scope"]["activity"];
      ppe = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["ppe"]
          : "null";
      first_aid = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["first_aid"]
          : "null";
      extinguisher = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["extinguisher"]
          : "null";
      induction = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["induction"]
          : "null";
      toolboxtalk = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["toolbox"]
          : "null";
//      JobApprovalResponse1 = graphQueryResult.data["job"]["lv1_approval"]["reason"];
//      JobApprovalResponse2 = graphQueryResult.data["job"]["lv2_approval"]["reason"];
//      JobApprovalResponse3 = graphQueryResult.data["job"]["lv3_approval"]["reason"];

      print("Status Id: " + JobStatusId.toString());
      print("Job Name : " + JobName.toString());
      print("Status Name: " + JobStatusType.toString());
//      print("Activities : " + JobActivity.toString());
      print("Reason 1 : " + JobRejectionResponse1.toString());
    }
    return true;
  }

  void changeJobStatusAccept() async {
    String jobStatusId = JobStatusId;
    String jobStatus = "PENDING";
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document:
            queryMutation.changeJobCardStatus(jobStatusId, jobStatus, null),
      ),
    );
    if (result.hasException) {
      Toast.show("data has errors", context);
    } else {
      Toast.show("Job card accepted", context);
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => safetyCompliance(jobId: JobId)));
//      Navigator.push(context, MaterialPageRoute(builder: (context) => FilePickerDemo()));
    }
  }

  Future<void> setData() async {
    animationController.forward();
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity1 = 1.0;
    });
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity2 = 1.0;
    });
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity3 = 1.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    double ui_width = (MediaQuery.of(context).size.width / 4).toDouble();
    double ui_rejected_width = (MediaQuery.of(context).size.width*0.75).toDouble();
    final double tempHeight = MediaQuery.of(context).size.height -
        (MediaQuery.of(context).size.width / 1.2) +
        24.0;
    if (_result == null) {
      // This is what we show while we're loading
      return new Container(
        color: Colors.white,
        child: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 300.0),
              Container(
                child: Image(image: new AssetImage("assets/adrian-loader.gif")),
                margin: const EdgeInsets.all(10.0),
                width: 120.0,
                height: 120.0,
              ),
            ],
          ),
        ),
      );
    }

    return new WillPopScope(
      onWillPop: _onWillPop,
      child: Container(
        color: AppTheme.nearlyWhite,
        child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Container(
              child: Column(
                children: <Widget>[
                  Container(
                    height: MediaQuery.of(context).size.height,
                    child: Stack(
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            AspectRatio(
                              aspectRatio: 1.0,
//                    child: Image.asset('assets/images/homepage/image_01.png'),
                              child: Container(
                                height: MediaQuery.of(context).size.height / 4,
//                            child: Container(),
//                            child: Container(),
                                decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomLeft,
                                        colors: [
                                      AppTheme.mainNavyBlue,
                                      AppTheme.mainPink
                                    ])),
                              ),
                            ),
                          ],
                        ),
                        Positioned(
                          top: (MediaQuery.of(context).size.width / 2.5) - 24.0,
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: Container(
                            height: MediaQuery.of(context).size.height * 0.9,
                            decoration: BoxDecoration(
                              color: AppTheme.nearlyWhite,
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(32.0),
                                  topRight: Radius.circular(32.0)),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                    color: AppTheme.grey.withOpacity(0.2),
                                    offset: const Offset(1.1, 1.1),
                                    blurRadius: 10.0),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 8, right: 8),
                              child: SingleChildScrollView(
                                child: Container(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      SizedBox(height: 8),

                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, right: 16, bottom: 8, top: 16),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Container(
                                              width: MediaQuery.of(context).size.width / 2,
                                              child: Text(
                                                'Scope of work: ',
                                                maxLines: 4,
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w200,
                                                  fontSize: 20,
                                                  letterSpacing: 0.27,
                                                  color: AppTheme.nearlyBlack,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              width:
                                              MediaQuery.of(context).size.width / 3,
                                              child: AutoSizeText(
                                                JobScopeName,
                                                maxLines: 4,
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 22,
                                                  letterSpacing: 0.27,
                                                  color: AppTheme.mainNavyBlue,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      AnimatedOpacity(
                                        duration:
                                            const Duration(milliseconds: 500),
                                        opacity: opacity1,
                                        child: Padding(
                                          padding: const EdgeInsets.all(3),
                                          child: Row(
                                            children: <Widget>[
                                              getTimeBoxUI(
                                                  JobStatusType, 'Status',ui_width ),
//                                              getTimeBoxUI(JobHazardRiskLevel,
//                                                  'Risk level',ui_width ),
                                              getTimeBoxUI(
                                                  JobDepartment, 'Department', ui_width ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      ExpansionTile(title: Text("Location",
                                        maxLines: 4,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w200,
                                          fontSize: 20,
                                          letterSpacing: 0.27,
                                          color: AppTheme.nearlyBlack,
                                        ),),
                                        children: <Widget>[
                                          Container(
                                            width:MediaQuery.of(context).size.width/2,
                                            child:Text(location_name,
                                              maxLines: 4,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w400,
                                                fontSize: 14,
                                                letterSpacing: 0.27,
                                                color: AppTheme.mainNavyBlue,
                                              ),),)
                                        ],),
//                                      AnimatedOpacity(
//                                        duration:
//                                            const Duration(milliseconds: 500),
//                                        opacity: opacity2,
//                                        child: Padding(
//                                          padding: const EdgeInsets.only(
//                                              left: 16,
//                                              right: 16,
//                                              top: 8,
//                                              bottom: 8),
//                                          child: Text(
//                                            JobActivity,
//                                            textAlign: TextAlign.justify,
//                                            style: TextStyle(
//                                              fontWeight: FontWeight.w300,
//                                              fontSize: 14,
//                                              letterSpacing: 0.27,
//                                              color: AppTheme.grey,
//                                            ),
//                                            maxLines: 3,
//                                            overflow: TextOverflow.ellipsis,
//                                          ),
//                                        ),
//                                      ),
                                      AnimatedOpacity(
                                        duration:
                                            const Duration(milliseconds: 500),
                                        opacity: opacity1,
                                        child: Padding(
                                          padding: const EdgeInsets.all(3),
                                          child: Row(
                                            children: <Widget>[
                                              Column(
                                                children: <Widget>[],
                                              ),
                                              getTimeBoxUI('Rejection Response',
                                                  JobRejectionResponse1, ui_rejected_width),
                                            ],
                                          ),
                                        ),
                                      ),
                                      ExpansionTile(
                                        title:
                                            Text("Safety Compliance Assesment",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w200,
                                                fontSize: 20,
                                                letterSpacing: 0.27,
                                                color: AppTheme.nearlyBlack,
                                              ),),
                                        children: <Widget>[
                                          ExpansionTile(
                                            title: Text('Photo Uploads'),
                                            children: <Widget>[
                                              Column(
                                                children: <Widget>[
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: <Widget>[
                                                      Column(
                                                        children: <Widget>[
                                                          Text(
                                                              "Personnel PPE Image"),
                                                          Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width /
                                                                3,
                                                            child: ppe == null
                                                                ? Container(
                                                                    width:
                                                                        180.0,
                                                                    height:
                                                                        270.0,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.all(
                                                                              Radius.circular(8.0)),
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                    child: Center(
                                                                        child: Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .center,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      children: <
                                                                          Widget>[
                                                                        Text(
                                                                          'No image',
                                                                          style: TextStyle(
                                                                              fontSize: 20,
                                                                              fontWeight: FontWeight.bold,
                                                                              color: Colors.grey),
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                        ),
                                                                      ],
                                                                    )),
                                                                  )
                                                                : Container(
                                                                    width:
                                                                        160.0,
                                                                    height:
                                                                        240.0,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.all(
                                                                              Radius.circular(8.0)),
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                    child: Image
                                                                        .network(
                                                                      ppe,
                                                                      height:
                                                                          150.0,
                                                                      width:
                                                                          100.0,
                                                                    ),
                                                                  ),
//              Image.file(ppe),
                                                          ),
                                                        ],
                                                      ),
                                                      Column(
                                                        children: <Widget>[
                                                          Text(
                                                              "First-aid Kit Image"),
                                                          Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width /
                                                                3,
                                                            child:
                                                                first_aid ==
                                                                        null
                                                                    ? Container(
                                                                        width:
                                                                            180.0,
                                                                        height:
                                                                            270.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Center(
                                                                            child: Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: <
                                                                              Widget>[
                                                                            Text(
                                                                              'No image',
                                                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey),
                                                                              textAlign: TextAlign.center,
                                                                            ),
                                                                          ],
                                                                        )),
                                                                      )
                                                                    : Container(
                                                                        width:
                                                                            160.0,
                                                                        height:
                                                                            240.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Image
                                                                            .network(
                                                                          first_aid,
                                                                          height:
                                                                              150.0,
                                                                          width:
                                                                              100.0,
                                                                        ),
                                                                      ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              Column(
                                                children: <Widget>[
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: <Widget>[
                                                      Column(
                                                        children: <Widget>[
                                                          Text(
                                                              "Fire Extinguisher Image"),
                                                          Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width /
                                                                3,
                                                            child:
                                                                extinguisher ==
                                                                        null
                                                                    ? Container(
                                                                        width:
                                                                            180.0,
                                                                        height:
                                                                            270.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Center(
                                                                            child: Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: <
                                                                              Widget>[
                                                                            Text(
                                                                              'No image',
                                                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey),
                                                                              textAlign: TextAlign.center,
                                                                            ),
                                                                          ],
                                                                        )),
                                                                      )
                                                                    : Container(
                                                                        width:
                                                                            160.0,
                                                                        height:
                                                                            240.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Image
                                                                            .network(
                                                                          extinguisher,
                                                                          height:
                                                                              150.0,
                                                                          width:
                                                                              100.0,
                                                                        ),
                                                                      ),
                                                          ),
                                                        ],
                                                      ),
                                                      Column(
                                                        children: <Widget>[
                                                          Text(
                                                              "Induction Form Image"),
                                                          Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width /
                                                                3,
                                                            child:
                                                                induction ==
                                                                        null
                                                                    ? Container(
                                                                        width:
                                                                            180.0,
                                                                        height:
                                                                            270.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Center(
                                                                            child: Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: <
                                                                              Widget>[
                                                                            Text(
                                                                              'No image',
                                                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey),
                                                                              textAlign: TextAlign.center,
                                                                            ),
                                                                          ],
                                                                        )),
                                                                      )
                                                                    : Container(
                                                                        width:
                                                                            160.0,
                                                                        height:
                                                                            240.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Image
                                                                            .network(
                                                                          induction,
                                                                          height:
                                                                              150.0,
                                                                          width:
                                                                              100.0,
                                                                        ),
                                                                      ),
//              Image.file(ppe),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              Column(
                                                children: <Widget>[
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: <Widget>[
                                                      Column(
                                                        children: <Widget>[
                                                          Text(
                                                              "Toolboxtalk Form Image"),
                                                          Container(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width /
                                                                3,
                                                            child:
                                                                toolboxtalk ==
                                                                        null
                                                                    ? Container(
                                                                        width:
                                                                            180.0,
                                                                        height:
                                                                            270.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Center(
                                                                            child: Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: <
                                                                              Widget>[
                                                                            Text(
                                                                              'No image',
                                                                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey),
                                                                              textAlign: TextAlign.center,
                                                                            ),
                                                                          ],
                                                                        )),
                                                                      )
                                                                    : Container(
                                                                        width:
                                                                            160.0,
                                                                        height:
                                                                            240.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.all(Radius.circular(8.0)),
                                                                          color:
                                                                              Colors.white,
                                                                        ),
                                                                        child: Image
                                                                            .network(
                                                                          toolboxtalk,
                                                                          height:
                                                                              150.0,
                                                                          width:
                                                                              100.0,
                                                                        ),
                                                                      ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          ExpansionTile(
                                            title: Text('Job Hazard Analysis'),
                                            children: <Widget>[],
                                          ),
                                          ExpansionTile(
                                            title: Text(
                                                'Documents used Confirmation'),
                                          ),
                                        ],
                                      ),
                                      AnimatedOpacity(
                                        duration:
                                            const Duration(milliseconds: 500),
                                        opacity: opacity3,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 16, bottom: 16, right: 16),
                                          child: Row(
                                            children: <Widget>[
                                              Container(
                                                width: 48,
                                                height: 48,
                                                child: GestureDetector(
                                                  onTap: () {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                NavigationHomeScreen()));
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color:
                                                          AppTheme.nearlyWhite,
                                                      borderRadius:
                                                          const BorderRadius
                                                              .all(
                                                        Radius.circular(16.0),
                                                      ),
                                                      border: Border.all(
                                                          color: AppTheme.grey
                                                              .withOpacity(
                                                                  0.2)),
                                                    ),
                                                    child: Icon(
                                                      Icons.arrow_back_ios,
                                                      color:
                                                          AppTheme.mainNavyBlue,
                                                      size: 28,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Spacer(),
                                              GestureDetector(
                                                onTap: () async {
                                                  //Accept JobCard goes here
                                                  changeJobStatusAccept();
                                                  Toast.show(
                                                      "Job card accepted",
                                                      context);
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              safetyCompliance(
                                                                  jobId:
                                                                      JobId)));
                                                },
                                                child: Container(
                                                  height: 48,
                                                  width: 200,
                                                  decoration: BoxDecoration(
                                                    color:
                                                        AppTheme.mainNavyBlue,
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                      Radius.circular(16.0),
                                                    ),
                                                    boxShadow: <BoxShadow>[
                                                      BoxShadow(
                                                          color: AppTheme
                                                              .mainNavyBlue
                                                              .withOpacity(0.5),
                                                          offset: const Offset(
                                                              1.1, 1.1),
                                                          blurRadius: 10.0),
                                                    ],
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      'Resubmit Job',
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 18,
                                                        letterSpacing: 0.0,
                                                        color: AppTheme
                                                            .nearlyWhite,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                width: 16,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 40,
                                      ),
                                      SizedBox(
                                        height: MediaQuery.of(context)
                                            .padding
                                            .bottom,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: (MediaQuery.of(context).size.width / 2.59) -
                              24.0 -
                              35,
                          right: 35,
                          child: ScaleTransition(
                            alignment: Alignment.center,
                            scale: CurvedAnimation(
                                parent: animationController,
                                curve: Curves.fastOutSlowIn),
                            child: Card(
                              color: AppTheme.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50.0)),
                              elevation: 10.0,
                              child: Container(
                                width: 60,
                                height: 60,
                                child: Center(
                                  child: Container(
                                    child: Image(
                                        image: new AssetImage(
                                            "assets/Arplogo.png")),
                                    width: 40.0,
                                    height: 40.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).padding.top),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            height: AppBar().preferredSize.height,
                            child: Material(
                                color: Colors.transparent,
                                child: Row(
                                  children: <Widget>[
                                    InkWell(
                                      borderRadius: BorderRadius.circular(
                                          AppBar().preferredSize.height),
                                      child: Icon(
                                        Icons.arrow_back_ios,
                                        color: Colors.white,
                                      ),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  NavigationHomeScreen()),
                                        );
                                      },
                                    ),
                                    SizedBox(width:MediaQuery.of(context).size.width/2.9),
                                    Container(
                                      width:MediaQuery.of(context).size.width/2,
                                      child: AutoSizeText(
                                        JobName,
                                        maxLines: 8,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 22,
                                          letterSpacing: 0.27,
                                          color: Colors.white,
                                        ),
                                      ),
                                    )
                                  ],
                                )),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            )),
      ),
    );
  }

  Widget getTimeBoxUI(String text1, String txt2, double ui_width) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: ui_width,
        constraints:
            new BoxConstraints(maxWidth: ui_width),
        decoration: BoxDecoration(
          color: AppTheme.nearlyWhite,
          borderRadius: const BorderRadius.all(Radius.circular(16.0)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: AppTheme.grey.withOpacity(0.2),
                offset: const Offset(1.1, 1.1),
                blurRadius: 8.0),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.only(
              left: 9.0, right: 9.0, top: 12.0, bottom: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                text1,
                maxLines: 6,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                  letterSpacing: 0.27,
                  color: AppTheme.mainNavyBlue,
                ),
              ),
              AutoSizeText(
                txt2,
                maxLines: 20,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w200,
                  fontSize: 11,
                  letterSpacing: 0.27,
                  color: AppTheme.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _onWillPop() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NavigationHomeScreen()),
//                        builder: (context) => RejectedCardInfoScreen(jobId: currentPage.round().toString())),
    );
  }
}
