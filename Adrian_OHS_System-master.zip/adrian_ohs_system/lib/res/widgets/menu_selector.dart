import 'package:flutter/cupertino.dart';

class menu_selector extends StatefulWidget {
  final List <String> menu_items;

  menu_selector({@required this.menu_items});
  @override
  _menu_selectorState createState() => _menu_selectorState();

}


  class _menu_selectorState extends State<menu_selector>
  {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Container();
  }

  }