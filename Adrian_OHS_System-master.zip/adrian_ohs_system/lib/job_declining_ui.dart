import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/res/ui/app_theme.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:toast/toast.dart';

import 'home_page.dart';
import 'navigation_home_screen.dart';
import 'res/graphql/graphQLMutations.dart';
import 'res/graphql/graphqlConf.dart';

class Comments extends StatefulWidget
{
  final String jobCardID;

  const Comments({Key key, @required this.jobCardID}) : super(key: key);
  @override
  _CommentsState createState() => _CommentsState(jobCardId: jobCardID);

}

class _CommentsState extends State<Comments>  {
  //This is the Job Card ID
  final String jobCardId;
  var jobIdToRejectComments;

  String JobStatusId;
  String JobStatusType;
  String JobDepartment;
  String JobName;
//  String JobHazardRiskLevel;
  String JobScopeName;
//  String JobActivity;

  var _result;

  String Reason;

  @override
  void initState() {
    super.initState();
    getJobCardDetails(jobCardId).then((result1){
      setState(() {
        _result = result1;
      });
    });

    print("JobId: "+jobCardId.toString());
    jobIdToRejectComments = jobCardId;
  }

  getJobCardDetails(String jobId) async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getASingleJobDetails(jobId),
      ),
    );
    if (!graphQueryResult.hasException) {
      JobName = graphQueryResult.data["job"]["name"];
      JobStatusId = graphQueryResult.data["job"]["status"]["id"];
      JobStatusType = graphQueryResult.data["job"]["status"]["type"];
      JobDepartment = graphQueryResult.data["job"]["scope"]["department"]["name"];
//      JobHazardRiskLevel = graphQueryResult.data["job"]["scope"]["hazard"];
      JobScopeName = graphQueryResult.data["job"]["scope"]["name"];
//      JobActivity = graphQueryResult.data["job"]["scope"]["activity"];
//          graphQueryResult.data["jobs"][i]["name"],
//          graphQueryResult.data["jobs"][i]["status"]["id"],
//          graphQueryResult.data["jobs"][i]["department"]["Name"],
//          graphQueryResult.data["jobs"][i]["technician"]["Name"],

      print("Status Id: "+JobStatusId.toString());
      print("Job Name : "+JobName.toString());
      print("Status Name: "+JobStatusType.toString());
//      print("Activities : "+JobActivity.toString());
    }
    return true;
  }

  _CommentsState({Key key, @required this.jobCardId});

  void changeJobStatusReject(String reason) async{
    String jobStatusId = JobStatusId;
    String jobStatus = "REJECTED";
    String jobStatusReason = reason;
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration ();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document: queryMutation.changeJobCardStatus(
            jobStatusId,
            jobStatus,
            jobStatusReason
        ),
      ),
    );
    if (result.hasException) {
      Toast.show("data has errors", context);
    }
  }

  @override
  Widget build(BuildContext context) {
    print("jjobCardId: "+jobCardId);
    // TODO: implement build
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
                Color(0xffe92759),
                Color(0xFF141FAC),
              ],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              tileMode: TileMode.clamp)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        resizeToAvoidBottomPadding: false,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SingleChildScrollView(
                child: Padding(
                  padding:
                  EdgeInsets.only(left: 28.0, right: 28.0, top: 60.0),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Text(
                            'State the reason for decline',
                            style: TextStyle(
                                fontSize: 22.5, color: Colors.white),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Container(
                        width: double.infinity,
                        height: 220,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.0),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black12,
                                  offset: Offset(0.0, 15.0),
                                  blurRadius: 15.0),
                              BoxShadow(
                                  color: Colors.black12,
                                  offset: Offset(0.0, -10.0),
                                  blurRadius: 10.0)
                            ]),
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 16.0, right: 16.0, top: 16.0),
                          child: Column(
                            children: <Widget>[
                              TextField(
                                maxLines: 8,
                                decoration: InputDecoration(
                                  hintText: 'Comment here',
                                  labelStyle:
                                  TextStyle(color: Colors.grey[500]),
                                  border: UnderlineInputBorder(
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    Reason = value;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      ButtonTheme(
                          minWidth: 150.0,
                          child: RaisedButton(
                            padding: const EdgeInsets.all(9.0),
                            onPressed: ()  {
                              changeJobStatusReject(Reason);
                              Toast.show("Job card rejected", context);
                              Navigator.push(context, MaterialPageRoute(builder: (context) => NavigationHomeScreen()));
                            },
                            color: AppTheme.mainNavyBlue,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20.0)),
                            child: new Text(
                              "Submit",
                              style: TextStyle(
                                  fontSize: 17.5, color: Colors.white),
                            ),
                          )),
                      SizedBox(
                        height: 10.0,
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
                        child: SizedBox(
                          width: AppBar().preferredSize.height,
                          height: AppBar().preferredSize.height,
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius:
                              BorderRadius.circular(AppBar().preferredSize.height),
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: AppTheme.white,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            ],),





        ),
      ),
    );
  }
}