class JobCard {
  JobCard(this.id, this.name, this.status, this.department, this.technician);

  final String id;
  final String name;
  final String status;
  final String department;
  final String technician;

  getJobId() => this.id;

  getJobName() => this.name;

  getJobStatus() => this.status;

  getJobDepartment() => this.department;

  getTechnician() => this.technician;
}