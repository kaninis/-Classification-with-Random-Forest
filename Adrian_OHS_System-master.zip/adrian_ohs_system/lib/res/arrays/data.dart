List<String> images = [
  "assets/images/homepage/construction.jpg",
  "assets/images/homepage/construction2.jpg",
  "assets/images/homepage/construction3.jpg",
  "assets/images/homepage/construction4.jpg",
];

List<String> title = [
  "Job 1",
  "Job 1",
  "Job 1",
  "Job 1",
];
