import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/res/graphql/graphQLMutations.dart';
import 'package:adrian_ohs_app/res/graphql/graphqlConf.dart';
import 'package:adrian_ohs_app/res/ui/app_theme.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';

import 'home_page.dart';
import 'res/model/model_incident_report.dart';
import 'navigation_home_screen.dart';

class job_closure extends StatefulWidget {
  final String jobId;
  final String jobStatusId;

  const job_closure({Key key, @required this.jobId, @required this.jobStatusId})
      : super(key: key);
  @override
  _job_closureState createState() =>
      _job_closureState(JobId: jobId, JobStatusId: jobStatusId);
}

class _job_closureState extends State<job_closure> {
  final String JobId;
  final String JobStatusId;

  String _job_id, _job_status_id, _incident_id, _incident_name;
  int _incident_number;
  List<String> incidentId = [];
  List<String> incidentNumber = [];
  final incident_number_controller = TextEditingController();
  final List<Map<String, String>> listOfIncidences = [];
  List<incidents> incidentName = List<incidents>();
  incidents selectedValue;

  _job_closureState(
      {Key key, @required this.JobId, @required this.JobStatusId});

  CreateList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getIncidence(),
      ),
    );
    if (!graphQueryResult.hasException) {
      for (var i = 0; i < graphQueryResult.data["closuretypes"].length; i++) {
        setState(() {
          incidentName.add(
            incidents(
              graphQueryResult.data["closuretypes"][i]["id"],
              graphQueryResult.data["closuretypes"][i]["name"],
            ),
          );
        });
      }

      print(incidentName.length.toString());
      int l = graphQueryResult.data["closuretypes"].length;
      incidentId.length = l;
      incidentNumber.length = l;
    }
  }

  saveIncidences() async {
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document:
            queryMutation.jobIncidences(_job_id, incidentId, incidentNumber),
      ),
    );
    if (result.hasException) {
      Toast.show("Safety data updated", context);
    } else {
      Toast.show("Safety has errors", context);
    }
    return true;
  }

  closeJob() async {
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document: queryMutation.closeJob(_job_status_id),
      ),
    );
    QueryResult result2 = await _client.mutate(
      MutationOptions(
        document: queryMutation.jobIncidences(
            _job_id,
            incidentId.where((i) => i != null).toList(),
            incidentNumber.where((i) => i != null).toList()),
      ),
    );
    if (result.hasException || result2.hasException) {
      Toast.show("Job closure updated", context);
    } else {
      print("Job status ID: $_job_status_id");
      Toast.show("Job closure has errors", context);
    }
    return true;
  }

  initState() {
    super.initState();
    CreateList();
    _job_id = JobId;
    _job_status_id = JobStatusId;
    print(incidentName.length);
    print(incidentNumber.length);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: <Widget>[
              Container(
                width: double.maxFinite,
                height: MediaQuery.of(context).size.height,
                child: Stack(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                      ),
                      child: Container(
                        height: MediaQuery.of(context).size.height / 4,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [
                              Color(0xffe92759),
                              Color(0xFF141FAC),
                            ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                tileMode: TileMode.clamp)),
                      ),
                    ),
                    Positioned(
                      top: 70,
                      left: MediaQuery.of(context).size.width/3,
                      child: Text(
                        'Incident Report',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                    Positioned(
                      top: 100,
                      child: Container(
                        padding: EdgeInsets.all(32),
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(62),
                                topRight: Radius.circular(62))),
                        child: Column(
                          children: <Widget>[
                            Text('Specify Incident Number'),
                            Container(
                              height: 350,
                              child: ListView.builder(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  itemCount: incidentName.length,
                                  itemBuilder: (context, index) {
                                    return Card(
                                      child: Row(
                                        children: <Widget>[
                                          Flexible(
                                            child: ListTile(
                                              trailing: Container(
                                                width: 70,
                                                child: TextFormField(
                                                  keyboardType:
                                                      TextInputType.number,
                                                  onChanged: (value) async {
                                                    print(index);
                                                    String incident_Id =
                                                        incidentName[index]
                                                            .getIncidentId();
                                                    print(incident_Id);
                                                    incidentId[index] =
                                                        incident_Id;
                                                    incidentNumber[index] =
                                                        value;
                                                  },
                                                ),
                                              ),
                                              title: Text(
                                                  "${incidentName[index].getIncidentName()}"),
                                            ),
                                          ),
//                                       Flexible(child: TextField(
//
//                                         decoration: InputDecoration(
//                                             border: InputBorder.none,
//                                             hintText: 'Enter Numer'
//                                         ),
//                                         onChanged: (value){
//                                           String incident_Id = incidentName[index].getIncidentId();
//                                           print(incident_Id);
//                                           incidentId.add(incident_Id);
//                                           incidentNumber[index] = value;
//
//                                         },
//                                       ))
//                                        Flexible(
//                                          child:CheckboxListTile(
//                                            value: document_inputs[index],
//                                            onChanged: (bool value) async{
//                                              documentSelect(value, index);
//                                              document = listDocuments[index].getDocumentName();
//
//                                              if (value == true) {
//                                                document_id.add("${listDocuments[index].getDocumentId()}");
//                                                hazard_color = Colors.black;
//                                              }else
//                                              {
//                                                document_id = document_id.where((id) => id != "${listDocuments[index].getDocumentId()}").toList();
//                                              }
//                                              SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();
//                                              sharedPreferences.setStringList('documents', document_id);
//                                            },
//                                            selected: listDocuments == null ? false : true,
//                                            title: Text(
//                                              "${listDocuments[index].getDocumentName()}",
//                                            ),
//                                          ) ,
//                                        ),
//                                        IconButton(
//                                          icon: Icon(Icons.file_download),
//                                          tooltip: 'download document',
//                                          onPressed: () async{
//                                            document = await listDocuments[index].getDocumentUrl();
//                                            List<String> filename = document.split("?")[0].split("/");
//                                            await FlutterDownloader.enqueue(
//                                              url: document,
//                                              fileName: filename[7].replaceAll("%20", " "),
//                                              savedDir: '/storage/emulated/0/Documents',
//                                              showNotification: true, // show download progress in status bar (for Android)
//                                              openFileFromNotification: true, // click on notification to open downloaded file (for Android)
//                                            );
//                                            print(document);
//                                            print(filename);
//                                          },
//                                        ),
                                        ],
                                      ),
                                    );
                                  }),
                            ),

//                            Row(
//                              children: <Widget>[
//
////                                DropdownButton<incidents>(
////                                  hint: Text("Select Incident"),
////                                  value: selectedValue,
////                                  onChanged: (incidents Value) {
////                                    setState(() {
////                                      selectedValue = Value;
////                                      print(selectedValue);
////                                      _incident_id = Value.id;
////                                      _incident_name = Value.name;
////                                      Toast.show(_incident_id, context);
////                                    });
////                                  },
////                                  items:
////                                  incidentName.map((incidents text_value) {
////                                    return DropdownMenuItem<incidents>(
////                                      value: text_value,
////                                      child: Row(
////                                        children: <Widget>[
////                                          SizedBox(
////                                            width: 10,
////                                          ),
////                                          Text(
////                                            text_value.name,
////                                            style:
////                                            TextStyle(color: Colors.black),
////                                          ),
////                                        ],
////                                      ),
////                                    );
////                                  }).toList(),
////                                ),
////                                SizedBox(
////                                  width: 10,
////                                ),
////                                Container(
////                                  height: 27,
////                                  width: 50,
////                                  child: TextField(
////                                    onChanged: (value) {
////                                      _incident_number = int.parse(
////                                          incident_number_controller.text);
////                                    },
////                                    controller: incident_number_controller,
////                                    decoration:
////                                    InputDecoration(hintText: 'no.'),
////                                  ),
////                                ),
////                                Spacer(),
////                                IconButton(
////                                    icon: Icon(Icons.add),
////                                    onPressed: () async {
////                                      Map<String, String> CreateMap = {};
////                                      CreateMap["Incident"] = _incident_name;
////                                      CreateMap["Number"] = incident_number_controller.text;
////                                      await listOfIncidences.add(CreateMap);
////                                      await saveIncidences();
////                                      incident_number_controller.clear();
////
////                                    })
//                              ],
//                            ),
//                            DataTable(
//                              columns: [
//                                DataColumn(label: Text('Incident')),
//                                DataColumn(label: Text('Number')),
//                              ],
//                              rows:
//                                  listOfIncidences // Loops through dataColumnText, each iteration assigning the value to element
//                                      .map(
//                                        ((element) => DataRow(
//                                              cells: <DataCell>[
//                                                DataCell(
//                                                  Text(element['Incident']),
//                                                ), //Extracting from Map element the value
//                                                DataCell(
//                                                    Text(element['Number']),
//                                                    showEditIcon: true,
//                                                    onTap: () {}),
//                                              ],
//                                            )),
//                                      )
//                                      .toList(),
//                            ),
//                            ),
                            ButtonTheme(
                                minWidth: 150.0,
                                child: RaisedButton(
                                  padding: const EdgeInsets.all(9.0),
                                  onPressed: () async {
                                    print(incidentName);
                                    print(incidentNumber);
                                    print(incidentId);
                                    await closeJob();

                                    Navigator.of(context).pushAndRemoveUntil(
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                NavigationHomeScreen()),
                                        (Route<dynamic> route) => false);
                                  },
                                  color: Color(0xff141fac),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(20.0)),
                                  child: new Text(
                                    "Save & Close",
                                    style: TextStyle(
                                        fontSize: 20, color: Colors.white),
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
