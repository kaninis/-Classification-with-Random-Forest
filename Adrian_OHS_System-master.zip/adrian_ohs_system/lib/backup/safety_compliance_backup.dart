import 'dart:collection';
import 'dart:convert';
import 'dart:ffi';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:exif/exif.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:adrian_ohs_app/res/graphql/graphQLMutations.dart';
import 'package:adrian_ohs_app/res/graphql/graphqlConf.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:toast/toast.dart';

import '../res/model/model_hazards.dart';
import '../home_page.dart';
import '../navigation_home_screen.dart';
import '../res/ui/app_theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

class safetyCompliance extends StatefulWidget {
  final String jobId;

  const safetyCompliance({Key key, @required this.jobId}) : super(key: key);

  @override
  _safetyComplianceState createState() => _safetyComplianceState(JobId: jobId);
}

class _safetyComplianceState extends State<safetyCompliance> {
  String token;
  GeoFirePoint _imgLocation;
  bool _imgHasLocation;
  void _checkGPSData() async {
    Map<String, IfdTag> imgTags = await readExifFromBytes( File(image.path).readAsBytesSync() );

    if (imgTags.containsKey('GPS GPSLongitude')) {
      setState(() {
        _imgHasLocation = true;
        _imgLocation = exifGPSToGeoFirePoint(imgTags);
      });
    }

  }

  GeoFirePoint exifGPSToGeoFirePoint(Map<String, IfdTag> tags) {

    final latitudeValue = tags['GPS GPSLatitude'].values.map<double>( (item) => (item.numerator.toDouble() / item.denominator.toDouble()) ).toList();
    final latitudeSignal = tags['GPS GPSLatitudeRef'].printable;


    final longitudeValue = tags['GPS GPSLongitude'].values.map<double>( (item) => (item.numerator.toDouble() / item.denominator.toDouble()) ).toList();
    final longitudeSignal = tags['GPS GPSLongitudeRef'].printable;

    double latitude = latitudeValue[0]
        + (latitudeValue[1] / 60)
        + (latitudeValue[2] / 3600);

    double longitude = longitudeValue[0]
        + (longitudeValue[1] / 60)
        + (longitudeValue[2] / 3600);

    if (latitudeSignal == 'S') latitude = -latitude;
    if (longitudeSignal == 'W') longitude = -longitude;

    return  GeoFirePoint(latitude, longitude);
  }
  List <String> hazard_id = [];
  final String JobId;
  String hazard;
  Color hazard_color = AppTheme.mainPink;

  final String url = "http://158.101.165.50/upload";
  File ppe, induction, toolboxtalk, emergency;
  String ppeURL, inductionURL, toolboxtalkURL, emergencyURL,first_aid_kitURL,fire_extinguisherURL;
  var image, file;

  String _extension;

  TextEditingController controller = new TextEditingController();

  _safetyComplianceState({Key key, @required this.JobId});
  Future<String> uploadPhoto(File _image, String _path, String type) async {
    SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();
    token = sharedPreferences.getString("token");
    print(_path);
    Dio dio = new Dio();
    FormData _formdata = new FormData();
    _formdata.add("file", new UploadFileInfo(_image, _path));
    final response = await dio.post(
      'http://158.101.165.50/upload',
      data: _formdata,
      options: Options(
        method: 'POST',
        headers: {
          "authorization":
              "$token",
        },
        responseType: ResponseType.json,
      ),
    );
    if (response.statusCode == 200 || response.statusCode == 500) {
      var jsonData = json.decode(response.toString());
      String ImageFileURL = jsonData["url"];
      print("ImageURL: " + ImageFileURL);
      if (type == "ppe") {
        ppeURL = ImageFileURL;
      } else if (type == "induction") {
        inductionURL = ImageFileURL;
      } else if (type == "toolboxtalk") {
        toolboxtalkURL = ImageFileURL;
      } else if (type == "emergency") {
        emergencyURL = ImageFileURL;
      }
//      return ImageURL;
    } else {
      throw Exception('Failed to upload!');
    }
  }

  final _controller = new PageController();
  static const _kDuration = const Duration(milliseconds: 300);
  static const _kCurve = Curves.ease;

  saveSafetyCompliance() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    List<String> hazards = sharedPreferences.getStringList('hazards');
    List<String> documents = sharedPreferences.getStringList('documents');
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document: queryMutation.updateSafetyCompliance(
            ppeURL, first_aid_kitURL,fire_extinguisherURL, inductionURL, toolboxtalkURL, emergencyURL, hazards,documents, JobId),
      ),
    );
    if (result.hasException) {
      Toast.show("Safety data has errors", context);
    } else {
      Toast.show("Safety updated", context);
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => new NavigationHomeScreen()));
    }
    return true;
  }
  List<hazards> listHazards = List<hazards>();
  List<bool> inputs = new List<bool>();
  int item_count;

  void ItemChange(bool val,int index){
    setState(() {
      inputs[index] = val;
    });
  }
  void fillList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getHazards(),
      ),
    );
    if (!graphQueryResult.hasException) {
      for (var i = 0; i < graphQueryResult.data["hazards"].length; i++) {
        setState(() {
          listHazards.add(
            hazards(
              graphQueryResult.data["hazards"][i]["id"],
              graphQueryResult.data["hazards"][i]["text"],
              graphQueryResult.data["hazards"][i]["consequence"],
//              graphQueryResult.data["hazards"][i]["controls"]["text"],
            ),
          );
        });
      }

      print(listHazards.length.toString());
    }
    item_count = graphQueryResult.data["hazards"].length;
  }

  @override
  initState(){
    super.initState();
    fillList();
    setState((){
      for(int i=0;i<20;i++){
        inputs.add(false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> _assessmentSteps = [
      Container(
          child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text("PPE image upload",
                style: TextStyle(
                  color: AppTheme.mainPink,
                  fontSize: 26.0,
                  fontFamily: "Calibre-Semibold",
                  letterSpacing: 1.0,
                )),
            SizedBox(
              height: 30.0,
            ),
            Container(
              child: ppe == null
                  ? Container(
                      width: 180.0,
                      height: 270.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue.withOpacity(0.7),
                      ),
                      child: Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'No image',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            "Click button below to select",
                            style: TextStyle(color: Colors.white),
                            textAlign: TextAlign.center,
                          )
                        ],
                      )),
                    )
                  : Container(
                      width: 160.0,
                      height: 240.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue,
                      ),
                      child: Image.file(
                        ppe,
                        height: 150.0,
                        width: 100.0,
                      ),
                    ),
//              Image.file(ppe),
            ),
//            RaisedButton(
//                child: Text('Choose PPE image'),
//                onPressed: () async {
//                  image = await ImagePicker.pickImage(source: ImageSource.gallery);
//                  setState(() {
//                    ppe = image;
//                    uploadPhoto(image,image.uri.toFilePath(),"ppe");
//                  });
//                }),
            SizedBox(
              height: 30.0,
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
            ButtonTheme(
                minWidth: 150.0,
                child: RaisedButton(
                  padding: const EdgeInsets.all(9.0),
                  onPressed: () async {
                    image = await ImagePicker.pickImage(
                        source: ImageSource.gallery);
                    _checkGPSData();
                    print(_imgLocation);
                    setState(() {
                      ppe = image;
                      uploadPhoto(image, image.uri.toFilePath(), "ppe");
                    });

                  },
                  color: Color(0xffe92759),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0)),
                  child: Icon(
                    Icons.camera_alt,
                    color: AppTheme.white,
                  ),
                )),
              Spacer(),
//            SizedBox(
//              height: 30.0,
//            ),
//            RaisedButton(
//                child: Text('Next'),
//                onPressed: () async {
//                  _controller.nextPage(duration: _kDuration, curve: _kCurve);
//                }),
            ButtonTheme(
                minWidth: 70.0,
                child: RaisedButton(
                  padding: const EdgeInsets.all(9.0),
                  onPressed: () async {
                    _controller.nextPage(duration: _kDuration, curve: _kCurve);
                  },
                  color: Color(0xff141fac),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0)),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    color: AppTheme.white,
                  ),
                )),

          ],),
            SizedBox(
              height: 100.0,
            ),
          ],
        ),
      )),
      Container(
          child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text("Induction form upload",
                style: TextStyle(
                  color: AppTheme.mainPink,
                  fontSize: 26.0,
                  fontFamily: "Calibre-Semibold",
                  letterSpacing: 1.0,
                )),
            SizedBox(
              height: 30.0,
            ),
            Container(
              child: induction == null
                  ? Container(
                      width: 180.0,
                      height: 270.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue.withOpacity(0.7),
                      ),
                      child: Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'No image',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            "Click button below to select",
                            style: TextStyle(color: Colors.white),
                            textAlign: TextAlign.center,
                          )
                        ],
                      )),
                    )
                  : Container(
                      width: 160.0,
                      height: 240.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue,
                      ),
                      child: Image.file(
                        induction,
                        height: 150.0,
                        width: 100.0,
                      ),
                    ),
            ),
//            RaisedButton(
//                child: Text('Upload Induction image'),
//                onPressed: () async {
//                  image = await ImagePicker.pickImage(source: ImageSource.gallery);
//                  uploadPhoto(image,image.uri.toFilePath(),"induction");
//                  setState(() {
//                    induction = image;
//                  });
//                }),
            SizedBox(
              height: 30.0,
            ),
            Row(
              children: <Widget>[
                ButtonTheme(
                    minWidth: 150.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        image = await ImagePicker.pickImage(
                            source: ImageSource.gallery);
                        setState(() {
                          induction = image;
                          uploadPhoto(image, image.uri.toFilePath(), "induction");
                        });
                      },
                      color: Color(0xffe92759),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.camera_alt,
                        color: AppTheme.white,
                      ),
                    )),
//            SizedBox(
//              height: 30.0,
//            ),
//            RaisedButton(
//                child: Text('Next'),
//                onPressed: () async {
//                  _controller.nextPage(duration: _kDuration, curve: _kCurve);
//                }),
              Spacer(),
                ButtonTheme(
                    minWidth: 70.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        _controller.nextPage(duration: _kDuration, curve: _kCurve);
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.white,
                      ),
                    )),
              ],
            ),

          ],
        ),
      )),
      Container(
          child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text("Toolbox talk form",
                style: TextStyle(
                  color: AppTheme.mainPink,
                  fontSize: 26.0,
                  fontFamily: "Calibre-Semibold",
                  letterSpacing: 1.0,
                )),
            SizedBox(
              height: 30.0,
            ),
            Container(
              child: toolboxtalk == null
                  ? Container(
                      width: 180.0,
                      height: 270.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue.withOpacity(0.7),
                      ),
                      child: Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'No image',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            "Click button below to select",
                            style: TextStyle(color: Colors.white),
                            textAlign: TextAlign.center,
                          )
                        ],
                      )),
                    )
                  : Container(
                      width: 160.0,
                      height: 240.0,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(8.0)),
                        color: AppTheme.mainNavyBlue,
                      ),
                      child: Image.file(
                        toolboxtalk,
                        height: 150.0,
                        width: 100.0,
                      ),
                    ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center ,
              children: <Widget>[
                ButtonTheme(
                    minWidth: 150.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        image = await ImagePicker.pickImage(
                            source: ImageSource.gallery);
                        setState(() {
                          toolboxtalk = image;
                          uploadPhoto(image, image.uri.toFilePath(), "toolboxtalk");
                        });
                      },
                      color: Color(0xffe92759),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.camera_alt,
                        color: AppTheme.white,
                      ),
                    )),
                Spacer(),
//            SizedBox(
//              height: 30.0,
//            ),
//            RaisedButton(
//                child: Text('Next'),
//                onPressed: () async {
//                  _controller.nextPage(duration: _kDuration, curve: _kCurve);
//                }),
                ButtonTheme(
                    minWidth: 70,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        _controller.nextPage(duration: _kDuration, curve: _kCurve);
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.white,
                      ),
                    )),
              ],
            ),

          ],
        ),
      )),
      Container(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Text("Job Hazard Analysis",
                    style: TextStyle(
                      color: AppTheme.mainPink,
                      fontSize: 26.0,
                      fontFamily: "Calibre-Semibold",
                      letterSpacing: 1.0,
                    )),
                Container(
                  height:350,
                  child: ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemCount: listHazards.length,
                    itemBuilder: (context, int index) {
                      return CheckboxListTile(
                        value: inputs[index],
                        onChanged: (bool value) async{
                          ItemChange(value, index);
                          hazard = listHazards[index].getJobHazard();
                          if(value == true) {
                            hazard_id.add("${listHazards[index].getJobId()}");
                            Toast.show(
                                "${hazard_id.join(",")}", context);
                            print(hazard_id);
                          }
                          else
                            {
                              hazard_id = hazard_id.where((id) => id != "${listHazards[index].getJobId()}").toList();
                            }
                          SharedPreferences sharedPreferences =  await SharedPreferences.getInstance();
                          sharedPreferences.setStringList('hazards', hazard_id);

                        },
                        selected: listHazards == null ? false : true,
                        title: Text(
                          "${listHazards[index].getJobHazard()}",
                        ),
                      );
                    },
                  ),
                ),
                ButtonTheme(
                    minWidth: 70.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        _controller.nextPage(duration: _kDuration, curve: _kCurve);
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: AppTheme.white,
                      ),
                    )),
              ],
            ),
          )),
//      Container(
//          child: SingleChildScrollView(
//            child: Column(
//              children: <Widget>[
//                Text("Job Hazard Analysis",
//                    style: TextStyle(
//                      color: AppTheme.mainPink,
//                      fontSize: 26.0,
//                      fontFamily: "Calibre-Semibold",
//                      letterSpacing: 1.0,
//                    )),
//                Container(
//                  height:350,
//                  child: ListView.builder(
//                    scrollDirection: Axis.vertical,
//                    shrinkWrap: true,
//                    itemCount: listHazards.length,
//                    itemBuilder: (context, int index) {
//                      return ExpansionTile(title: Text("${listHazards[index].getJobHazard()}",
//                          style: TextStyle(
//                            color: hazard_color,
//                            fontSize: 15.0,
//                            fontFamily: "Calibre-Semibold",
//                            letterSpacing: 1.0,
//                          )),
//                        children: <Widget>[
//                          SingleChildScrollView(
//                          child: Container(
//                            height:200,
//                            child:ListView.builder(
//                                    scrollDirection: Axis.vertical,
//                                    shrinkWrap: true,
//                                    itemCount: listHazards.length,
//                                    itemBuilder: (context, index) {
//                                      return CheckboxListTile(
//                                        value: inputs[index],
//                                        onChanged: (bool value) {
//                                          ItemChange(value, index);
//                                          hazard = listHazards[index].getConsequence();
//
//
//                                          if(value == true) {
//                                            Toast.show(
//                                                "${listHazards[index].getConsequence()}", context);
//                                            hazard_color = Colors.black;
//                                          }
//
//                                        },
//                                        selected: listHazards == null ? false : true,
//                                        title: Text(
//                                          "${listHazards[index].getControls()}",
//                                        ),
//                                      );
//                                    })
//                          ),
//                      ),
//
//                        ],);
////                        CheckboxListTile(
////                        value: inputs[index],
////                        onChanged: (bool value) {
////                          ItemChange(value, index);
////                          hazard = listHazards[index].getJobHazard();
////                          if(value == true) {
////                            Toast.show(
////                                "${listHazards[index].getJobHazard()}", context);
////                          }
////
////
////                        },
////                        selected: listHazards == null ? false : true,
////                        title: Text(
////                          "${listHazards[index].getJobHazard()}",
////                        ),
////                      );
//                    },
//                  ),
//                ),
//                ButtonTheme(
//                    minWidth: 150.0,
//                    child: RaisedButton(
//                      padding: const EdgeInsets.all(9.0),
//                      onPressed: () async {
//                        _controller.nextPage(duration: _kDuration, curve: _kCurve);
//                      },
//                      color: Color(0xff141fac),
//                      shape: RoundedRectangleBorder(
//                          borderRadius: BorderRadius.circular(20.0)),
//                      child: Icon(
//                        Icons.arrow_forward_ios,
//                        color: AppTheme.white,
//                      ),
//                    )),
//              ],
//            ),
//          )),
      Container(
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Text("ERP form",
                    style: TextStyle(
                      color: AppTheme.mainPink,
                      fontSize: 26.0,
                      fontFamily: "Calibre-Semibold",
                      letterSpacing: 1.0,
                    )),
                SizedBox(
                  height: 30.0,
                ),
                Container(
                  child: emergency == null
                      ? Container(
                    width: 180.0,
                    height: 270.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(8.0)),
                      color: AppTheme.mainPink.withOpacity(0.7),
                    ),
                    child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'No document',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              "Click button below to select",
                              style: TextStyle(color: Colors.white),
                              textAlign: TextAlign.center,
                            )
                          ],
                        )),
                  )
                      :
                  Container(
                    width: 160.0,
                    height: 240.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(8.0)),
                    ),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: 160,
                          height: 160,
                          child: Icon(Icons.done, size: 60, color: Colors.white,),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF32CD32)),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Text("Document Uploaded")
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 15.0,
                ),
                ButtonTheme(
                    minWidth: 150.0,
                    child: RaisedButton(
                      padding: const EdgeInsets.all(9.0),
                      onPressed: () async {
                        file = await FilePicker.getFile(type: FileType.CUSTOM, fileExtension: "docx");
                        setState(() {
                          emergency = file;
                          uploadPhoto(file, "${file.uri.toFilePath()}.docx", "emergency");
                        });
                      },
                      color: Color(0xff141fac),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                      child: Icon(
                        Icons.description,
                        color: AppTheme.white,
                      ),
                    )),
                SizedBox(
                  height: 5.0,
                ),
                ButtonTheme(
                    minWidth: 250.0,
                    child: Center(
                      child: RaisedButton(
                          color: Color(0xffe92759),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.0)),
                          child: Text('Submit',
                              style: TextStyle(
                                color: AppTheme.white,
                                fontSize: 20.0,
                                fontFamily: "Calibre-Semibold",
                                letterSpacing: 1.0,
                              )),
                          onPressed: () async {
                            saveSafetyCompliance();
                          }),
                    )),
                SizedBox(
                  height: 200.0,
                ),
              ],
            ),
          )),


    ];
    return Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: <Widget>[
              Container(
                width: double.maxFinite,
                height: MediaQuery.of(context).size.height,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: 0,
                      bottom: MediaQuery.of(context).size.height / 2,
                      child: Image.asset(
                        'assets/images/homepage/image_02.jpg',
                      ),
                    ),
                    Positioned(
                      top: 100,
                      left: 20,
                      child: Text(
                        'Safety Compliance Assessment',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.mainNavyBlue),
                      ),
                    ),
                    Positioned(
                      top: 190,
                      child: Container(
                        padding: EdgeInsets.all(32),
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(62),
                                topRight: Radius.circular(62))),
                        child: Column(
                          children: <Widget>[
                            Flexible(
                              child: PageView.builder(
                                controller: _controller,
                                itemCount: _assessmentSteps.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return _assessmentSteps[
                                      index % _assessmentSteps.length];
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
