import 'dart:convert';

class NotificationModel {
  final String id;
  final String uid;
  final String title;
  final String body;
  final String notifiedAtDate;

  NotificationModel(
      { this.id,
        this.uid,
        this.title,
        this.body,
        this.notifiedAtDate});

  factory NotificationModel.fromMap(Map<String, dynamic> json) =>
      new NotificationModel(
        id: json["id"].toString(),
        uid: json["uid"],
        title: json["title"],
        body: json["body"],
        notifiedAtDate: json["notified_at_date"],
      );

  factory NotificationModel.fromMapForAssignees(Map<String, dynamic> json) =>
      new NotificationModel(
        id: json["id"].toString(),
        uid: json["uid"],
        title: json["title"],
        body: json["body"],
        notifiedAtDate: json["notifiedAtDate"],
      );


  factory NotificationModel.fromMapForAccountabilityPartners(
      Map<String, dynamic> json) =>
      new NotificationModel(
        id: json["id"].toString(),
        uid: json["uid"],
        title: json["title"],
        body: json["body"],
        notifiedAtDate: json["notifiedAtDate"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "uid": uid,
        "title": title,
        "body": body,
        "notifiedAtDate": notifiedAtDate,
      };


  factory NotificationModel.fromMapForLoggedInUserProfileDetails(
      Map<String, dynamic> json) =>
      new NotificationModel(
        id: json["id"].toString(),
        uid: json["uid"],
        title: json["title"],
        body: json["body"],
        notifiedAtDate: json["notifiedAtDate"]
      );
}

NotificationModel ContactFromJson(String str) {
  final jsonData = json.decode(str);
  return NotificationModel.fromMap(jsonData);
}

String ContactToJson(NotificationModel data) {
  final dyn = data.toMap();
  return json.encode(dyn);
}