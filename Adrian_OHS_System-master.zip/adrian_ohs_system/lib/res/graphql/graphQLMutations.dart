class QueryMutation {
  String getAllJobs(String filter) {
    String valuable = """ 
      query{
            jobs{
              id
              name
              location_name
              status{
                id
                type
              }
          
              scope{
                id
                name
                department{
                 id
                 name
                 division{
                      id
                      name
                 }
                 manager{
                    id 
                    name
                    phone
                 }
                }
              }
              technician{
                id
                name
                phone
                type{
                  id
                  name
                }
              }
            }
          }
    """;
    print(valuable);
    return valuable;
  }

  String getAllTechnicianJobs(String filter) {
    String queryString = """ 
      query{
            technicianJobs(filter: $filter){
              id
              name
              location_name
              status{
                id
                type
              }
         
              scope{
                id
                name
                department{
                 id
                 name
                 division{
                      id
                      name
                 }
                 manager{
                    id 
                    name
                    phone
                 }
                }
              }
              technician{
                id
                name
                phone
                type{
                  id
                  name
                }
              }
            }
          }
    """;
//    print(queryString);
    return queryString;
  }

  String getAllNewJob(String filter) {
    return """ 
      query{
            technicianJobs(filter: $filter){
              id
              name
              location_name
              status{
                id
                type
              }
         
              scope{
                id
                name
                department{
                 id
                 name
                 division{
                      id
                      name
                 }
                 manager{
                    id 
                    name
                    phone
                 }
                }
              }
              technician{
                id
                name
                phone
                type{
                  id
                  name
                }
              }
            }
          }
    """;
  }

  String getAllDocuments() {
    return """ 
      query{
            documents{
              id
              name
              url
            }
          }
    """;
  }
  String getControls (String id){
    return """
    query{
          hazard(hazard:{id: "$id"})
          {
             id
             text
             controls{
                      id
                      text
                    }
          
          }
    }
  
     """;
  }

  String getASingleJobDetails(String id) {
    return """ 
      query{
            job(job:{id:"$id"}){
              id
              name
              location_name
              status{
                id
                type
                reason
              }
         
              scope{
                id
                name
                department{
                 id
                 name
                 division{
                      id
                      name
                 }
                 manager{
                    id 
                    name
                    phone
                 }
                }
              }
              technician{
                id
                name
                phone
                type{
                  id
                  name
                }
              }
              lv1_approval{
                id
                level
                status
                reason
                approver{
                  id
                  name
                 }
               }
               lv2_approval{
                id
                level
                status
                reason
                approver{
                  id
                  name
                 }
               }
               lv3_approval{
                id
                level
                status
                reason
                approver{
                  id
                  name
                 }
               }
                lv4_approval{
                id
                level
                status
                reason
                approver{
                  id
                  name
                 }
               }
               compliance{
                          id
                          induction
                          ppe
                          toolbox
                          erp
                          first_aid
                          extinguisher
                          documents{
                                    id
                                    name
                                    }
                          jha   {
                                    id
                                    text
                                controls{
                                          id
                                          text
                                }
                              }
                          }
                          closure{
                              id
                              closuretype{
                                    id 
                                    name
                              }
                              amount 
                          }
            }
          }
    """;
  }

  String changeJobCardStatus(String id, var status, String reason) {
    print(id);
    print(status);
    print(reason);
    return """
      mutation{
          status{
              update(
                status:{
                  id: "$id",
                  type: $status,
                  reason: "$reason"
                }
            ){
              id
            }
          }
      }    
     """;
  }

  String updateSafetyCompliance(
      String ppeUrl,
      String first_aid_kitUrl,
      String fire_extinguisherUrl,
      String inductionUrl,
      String toolboxUrl,
      String emergencyUrl,
      List<String> hazards,
      List<String> documents,
      String jobiD) {
    print(jobiD);
    print(ppeUrl);
    print(inductionUrl);
    print(toolboxUrl);
    print(emergencyUrl);
    print(first_aid_kitUrl);
    print(fire_extinguisherUrl);
    String safetyMutation = """
      mutation{
          compliances{
              create(
                compliance:{
                  ppe: "$ppeUrl",
                  first_aid:"$first_aid_kitUrl"
                  extinguisher:"$fire_extinguisherUrl"
                  induction: "$inductionUrl",
                  toolbox: "$toolboxUrl",
                  erp: "$emergencyUrl",
                  documents: ${documents.map((doc) => "\"" + doc + "\"").toList()},
                  jha: ${hazards.map((hazard) => "\"" + hazard + "\"").toList()},
                  job: "$jobiD"
                }
            ){
              id
            }
          }
      }    
     """;
    print(safetyMutation);
    return safetyMutation;
  }

  String updateUserFCMToken(String userId, String fcmToken) {
    print(userId);
    print(fcmToken);
    return """
      mutation{
          users{
              update(
                user:{
                  id: "$userId",
                  fcm: "$fcmToken"
                }
            ){
              id
            }
          }
      }    
     """;
  }

  String jobIncidences(
      String job_id, List<String> incident_id, List<String> incident_number) {
    String incidentsMutation = """
      mutation{
          closures{
              create(
                closure:{
                  closuretype: ${incident_id.map((i) => "\"" + i + "\"").toList()}
                  job: "$job_id"
                  amount: ${incident_number.map((i) => "\"" + i + "\"").toList()}
            
                }
            ){
              id
            }
          }
      }    
     """;
    print(incidentsMutation);
    return incidentsMutation;
  }

  String closeJob(String statusId) {
    String incidentsMutation = """
      mutation{ 
         status{ 
            update(status:{ 
               id:"$statusId",
               type:COMPLETE
            }      ){ 
               id
            }
         }
      }
     """;
    print(incidentsMutation);
    return incidentsMutation;
  }

  String editJobCard(String id, String status) {
    print(id);
    print(status);
    return """
      mutation{
          jobs{
              update(
                job:{
                  id: "$id",
                  status: "$status"
                }
            ){
              id
            }
          }
      }    
     """;
  }

  String getHazards() {
    return """ 
      query{
            hazards{
              id
              text
              consequence
              controls{
                id
                text
              }
             }
          }
    """;
  }

  String getIncidence() {
    return """ 
      query{
            closuretypes{
              id
              name
             }
          }
    """;
  }
}
