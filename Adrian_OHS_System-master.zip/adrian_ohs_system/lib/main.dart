import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/login_page.dart';
import 'package:adrian_ohs_app/reset_password.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:random_string/random_string.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import 'navigation_home_screen.dart';
import 'res/db/db_notifications.dart';
import 'res/graphql/graphQLMutations.dart';
import 'res/graphql/graphqlConf.dart';
import 'res/model/model_notification.dart';
void main() async {
  Widget _defaultHome;
  String token;
  WidgetsFlutterBinding.ensureInitialized();
 FlutterDownloader.initialize();
  final PermissionHandler _permissionHandler = PermissionHandler();
  var result = await _permissionHandler.requestPermissions([PermissionGroup.storage]);
  var result2 = await _permissionHandler.requestPermissions([PermissionGroup.location]);

    SharedPreferences prefs = await SharedPreferences.getInstance();
    token = prefs.getString('token');
 if(result[PermissionGroup.storage]!= PermissionStatus.granted && result2[PermissionGroup.location]!= PermissionStatus.granted){
   await _permissionHandler.requestPermissions([PermissionGroup.storage]);
   await _permissionHandler.requestPermissions([PermissionGroup.location]);
  }
 if (token == null) {
    print('no user');
    _defaultHome = new login();
  }

  else{
   _defaultHome = new NavigationHomeScreen();
    print("permission not Granted");
  }
  runApp(MaterialApp(
    home:  _defaultHome,
    debugShowCheckedModeBanner: false,
    routes: <String, WidgetBuilder>{
      'landingpage': (BuildContext context) => MyApp(),
      'Homepage': (BuildContext context) => NavigationHomeScreen(),
      'login': (BuildContext context) => login(),
      'reset_password': (BuildContext context) => reset(),
    },
    theme: ThemeData.light().copyWith(
    ),
    title: 'Adrian OHS System',
  ));
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return null;
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Future initState() async {
    final FirebaseMessaging _fcm = FirebaseMessaging();
    String fcmToken = await _fcm.getToken();

    void changeJobStatus(fcmToken) async{
      String userId = "5e216e3a9e717c001773659f";
      String userToken = fcmToken;
      GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
      QueryMutation queryMutation = QueryMutation();
      GraphQLClient _client = graphQLConfiguration.clientToQuery();
      QueryResult result = await _client.mutate(
        MutationOptions(
          document: queryMutation.updateUserFCMToken(
              userId,
              userToken
          ),
        ),
      );
      if (!result.hasException) {
        Toast.show("Notification setup", context);
        print("Notification setup");
      }else{
        print("Error: "+result.exception.toString());
      }
    }

    // Send fcmToken to API
    if (fcmToken != null) {
      print("fcmToken: "+fcmToken);
      changeJobStatus(fcmToken);
    }else{
      print("FCM token null");
    }

    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Safety Compliance Assessment'),
      ),
      body: Query(
          options: QueryOptions(document: r"""
          query{
            jobs{
              id
              name
              department{
                id
                name
              }
              scope{
                id
                name
                division
                hazard
                activity
                controls
              }
              technician{
                id
                name
                phone
                type
              }
            }
          }
          """),
          builder: (
              QueryResult result, {
                VoidCallback refetch,
                FetchMore fetchMore,
              }) {
            if (result.data == null) {
              return Text("No Data Found");
            }
            return ListView.builder(
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  title: Text(result.data['jobs'][index]['name']),
                );
              },
              itemCount: result.data['jobs'].length,
            );
          }),
// This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  storeNotification(notification) async {
    await DBProviderNotifications.dbNotifications.newNotification(notification);
  }
}