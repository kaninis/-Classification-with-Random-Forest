class incidents {
  incidents(this.id, this.name);

  final String id;
  final String name;



  getIncidentId() => this.id;

  getIncidentName()  => this.name;



}