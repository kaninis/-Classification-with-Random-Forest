class documents {
  documents(this.id, this.name, this.url);

  final String id;
  final String name;
  final String url;
//  final List<String> controls;



  getDocumentId() => this.id;

  getDocumentName()  => this.name;

  getDocumentUrl() => this.url;

//  getControls() => this.controls;


}