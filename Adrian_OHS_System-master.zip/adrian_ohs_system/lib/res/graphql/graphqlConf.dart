import "package:flutter/material.dart";
import "package:graphql_flutter/graphql_flutter.dart";
import 'package:shared_preferences/shared_preferences.dart';

class GraphQLConfiguration {

  static String token;

  static HttpLink httpLink =
  HttpLink(uri: "http://158.101.165.50/graph");

  static final AuthLink authlink = AuthLink(
      getToken: () async {
        SharedPreferences sharedpreference = await SharedPreferences.getInstance();
        token = sharedpreference.getString("token");
        'Bearer $token';
        return token;
      }
  );

  static final Link link = authlink.concat(httpLink);

  ValueNotifier<GraphQLClient> client = ValueNotifier(
    GraphQLClient(
      link: link as Link,
      cache: OptimisticCache(
          dataIdFromObject: typenameDataIdFromObject
      ),
    ),
  );

  GraphQLClient clientToQuery() {
    return GraphQLClient(
      cache: OptimisticCache(dataIdFromObject: typenameDataIdFromObject),
      link: link as Link,
    );
  }

}