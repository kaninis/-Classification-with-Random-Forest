import 'dart:math';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/card_info_screen.dart';
import 'package:adrian_ohs_app/main.dart';
import 'package:adrian_ohs_app/res/arrays/data.dart';
import 'package:adrian_ohs_app/res/db/db_notifications.dart';
import 'package:adrian_ohs_app/res/model/model_notification.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:random_string/random_string.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import 'login_page.dart';
import 'job_declining_ui.dart';
import 'navigation_home_screen.dart';
import 'res/graphql/graphQLMutations.dart';
import 'res/graphql/graphqlConf.dart';
import 'res/model/model_job_card.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key key}) : super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}

var cardAspectRatio = 12.0 / 16.0;
var widgetAspectRatio = cardAspectRatio * 1.2;

GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();

List<JobCard> listCard = List<JobCard>();

QueryResult graphQueryResult;

class _HomePageState extends State<HomePage> {
  var currentPage = 0.0;
  int item_count;
  String job_id;

  var _result;

  @override
  initState(){
    super.initState();
    notificationSetUp();
    fillList().then((result1){
      setState(() {
        _result = result1;
      });
    });
  }

  void notificationSetUp() async {
    print("Fai");
    final FirebaseMessaging _fcm = FirebaseMessaging();
    String fcmToken = await _fcm.getToken();

    void changeJobStatus(fcmToken) async{
      String userId;
      SharedPreferences sharedpreference = await SharedPreferences.getInstance();
      userId = sharedpreference.getString("userid");
      print("userId: "+userId);
      String userFcmToken = fcmToken;
      GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
      QueryMutation queryMutation = QueryMutation();
      GraphQLClient _client = graphQLConfiguration.clientToQuery();
      QueryResult result = await _client.mutate(
        MutationOptions(
          document: queryMutation.updateUserFCMToken(
              userId,
              userFcmToken
          ),
        ),
      );
      if (!result.hasException) {
        Toast.show("Notification setup", context);
        print("Notification setup");
      }else{
        print("Errorz: "+result.exception.toString());
      }
    }

    // Send fcmToken to API
    if (fcmToken != null) {
      print("fcmToken: "+fcmToken);
      changeJobStatus(fcmToken);
    }else{
      print("FCM token null");
    }

    _fcm.configure(

      onMessage: (Map<String, dynamic> message) async {
        String randomNotificationString = randomAlphaNumeric(21);
        DateTime notificationDateToday = DateTime.now();
        String formattedNotificationDateToday = notificationDateToday.toString();

        var notificationDetails = NotificationModel(
          uid: randomNotificationString,
          title: message['notification']['title'],
          body: message['notification']['body'],
          notifiedAtDate: formattedNotificationDateToday,
        );
        NotificationModel insertNotificationDetail = notificationDetails;
        storeNotification(insertNotificationDetail);

        print("onMessage: $message");
        showDialog(
          context: context,
          builder: (context) =>
              AlertDialog(
                content: ListTile(
                  title: Text(message['notification']['title']),
                  subtitle: Text(message['notification']['body']),
                ),
                actions: <Widget>[
                  FlatButton(
                    child: Text('Ok'),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
        );
      },
      onLaunch: (Map<String, dynamic> message) async {
        String randomNotificationString = randomAlphaNumeric(21);
        DateTime notificationDateToday = DateTime.now();
        String formattedNotificationDateToday = notificationDateToday.toString();

        var notificationDetails = NotificationModel(
          uid: randomNotificationString,
          title: message['notification']['title'],
          body: message['notification']['body'],
          notifiedAtDate: formattedNotificationDateToday,
        );
        NotificationModel insertNotificationDetail = notificationDetails;
        storeNotification(insertNotificationDetail);

        print("onLaunch: $message");
        // TODO optional
      },
      onResume: (Map<String, dynamic> message) async {
        String randomNotificationString = randomAlphaNumeric(21);
        DateTime notificationDateToday = DateTime.now();
        String formattedNotificationDateToday = notificationDateToday.toString();

        var notificationDetails = NotificationModel(
          uid: randomNotificationString,
          title: message['notification']['title'],
          body: message['notification']['body'],
          notifiedAtDate: formattedNotificationDateToday,
        );
        NotificationModel insertNotificationDetail = notificationDetails;
        storeNotification(insertNotificationDetail);

        print("onResume: $message");
        // TODO optional
      },
    );
  }

  fillList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getAllNewJob("NEW"),
      ),
    );
    listCard.clear();
    if(graphQueryResult.data["technicianJobs"] != null) {
      if (!graphQueryResult.hasException) {
        for (var i = 0; i < graphQueryResult.data["technicianJobs"].length; i++) {
          setState(() {
            listCard.add(
              JobCard(
                graphQueryResult.data["technicianJobs"][i]["id"],
                graphQueryResult.data["technicianJobs"][i]["name"],
                graphQueryResult.data["technicianJobs"][i]["status"]["id"],
                graphQueryResult
                    .data["technicianJobs"][i]["scope"]["department"]["name"],
                graphQueryResult
                    .data["technicianJobs"][i]["technician"]["name"],
              ),
            );
          });
        }
        print("listCard length "+listCard.length.toString());
        print("Current Page "+currentPage.toString());
      }
      currentPage = listCard.length - 1.0;
      item_count = graphQueryResult.data["technicianJobs"].length;
      print("item_count: "+item_count.toString());
    }
    return true;
  }

  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await Future.delayed(Duration(seconds: 2));

    Navigator.of(context).pushAndRemoveUntil(
      // the new route
      MaterialPageRoute(
        builder: (BuildContext context) => login(),
      ),
          (Route route) => false,
    );
  }
  void _showDialog() {
    // flutter defined function
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Center(child: Text('Fiber Installation Job Card')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  child: Text(
                    "message",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.red,
                    ),
                  ),
                ),
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      RaisedButton(
                        padding: const EdgeInsets.all(9.0),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage()));
                        },
                        color: Colors.blue[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: new Text(
                          "Accept",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),
                        ),
                      ),
                      RaisedButton(
                        padding: const EdgeInsets.all(9.0),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Comments()));
                        },
                        color: Colors.blue[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: new Text(
                          "Decline",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),
                        ),
                      )
                    ])
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {

    PageController controller = PageController();
    controller.addListener(() {
      setState(() {
        currentPage = controller.page;
      });
    });

    if (_result == null) {
      // This is what we show while we're loading
      return new Container(
        color: Colors.white,
        child: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 300.0),
              Container(
                child: Image(image: new AssetImage("assets/Arplogo.png")),
                margin: const EdgeInsets.all(10.0),
                width: 120.0,
                height: 120.0,
              ),
            ],
          ),
        ),
      );
    }
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
                Color(0xffe92759),
                Color(0xFF141FAC),
              ],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              tileMode: TileMode.clamp)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(
                    left: 12.0, right: 12.0, top: 30.0, bottom: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    SizedBox(
                      height: 60.0,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text("Job cards",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26.0,
                          fontFamily: "Calibre-Semibold",
                          letterSpacing: 1.0,
                        )),
                    IconButton(
                      icon: Icon(
                        Icons.refresh,
                        size: 24.0,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => NavigationHomeScreen()));

                      },
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFff6e6e),
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 22.0, vertical: 6.0),
                          child: Text("New Jobs",
                              style: TextStyle(color: Colors.white)),
                        ),
                      ),
                    ),
//
                    SizedBox(
                      width: 15.0,
                    ),
//
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  print("Current Page: "+currentPage.toString());
//
                  if(graphQueryResult.data["technicianJobs"].length != 0){
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => CardInfoScreen(jobId: graphQueryResult.data["technicianJobs"][currentPage.round()]["id"].toString())),
                    );
                  }
                },
                child: Stack(
                  children: <Widget>[
                    CardScrollWidget(currentPage),
                    Positioned.fill(
                      child: PageView.builder(
                        itemCount: item_count,
                        controller: controller,
                        reverse: true,
                        itemBuilder: (context, index) {
                          return Container();
                        },
                      ),
                    )
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );

//    return Scaffold(
//      resizeToAvoidBottomPadding: false,
//        backgroundColor: Colors.white,
//        body:
//        RaisedButton(
//          padding: const EdgeInsets.all(9.0),
//          onPressed: _showDialog,
//          color: Colors.blue[700],
//          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
//          child: new Text(
//            "Job Notification",
//            style: TextStyle(fontSize: 20, color: Colors.white),
//          ),
//        ),
//    );
    // TODO: implement build

  }
}


storeNotification(notification) async {
  await DBProviderNotifications.dbNotifications.newNotification(notification);
}

class CardScrollWidget extends StatelessWidget {
  var currentPage;
  var padding = 20.0;
  var verticalInset = 20.0;

  CardScrollWidget(this.currentPage);



  @override
  Widget build(BuildContext context) {

    return new AspectRatio(
      aspectRatio: widgetAspectRatio,
      child: LayoutBuilder(builder: (context, contraints) {
        var width = contraints.maxWidth;
        var height = contraints.maxHeight;

        var safeWidth = width - 2 * padding;
        var safeHeight = height - 2 * padding;

        var heightOfPrimaryCard = safeHeight;
        var widthOfPrimaryCard = heightOfPrimaryCard * cardAspectRatio;

        var primaryCardLeft = safeWidth - widthOfPrimaryCard;
        var horizontalInset = primaryCardLeft / 2;

        List<Widget> cardList = new List();
//        currentPage = listCard.length - 1.0;

        for (var i = 0; i < listCard.length; i++) {
          var delta = i - currentPage;
          bool isOnRight = delta > 0;

          var start = padding +
              max(
                  primaryCardLeft -
                      horizontalInset * -delta * (isOnRight ? 15 : 1),
                  0.0);
          var cardItem = Positioned.directional(
            top: padding + verticalInset * max(-delta, 0.0),
            bottom: padding + verticalInset * max(-delta, 0.0),
            start: start,
            textDirection: TextDirection.rtl,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Container(
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.black12,
                      offset: Offset(3.0, 6.0),
                      blurRadius: 10.0)
                ]),
                child: AspectRatio(
                  aspectRatio: cardAspectRatio,
                  child: Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      Image.asset(images[0], fit: BoxFit.cover),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 8.0),
                              child: Container(
                                width: MediaQuery.of(context).size.width/3,
                                height: MediaQuery.of(context).size.height/15,
                                padding: EdgeInsets.symmetric(
                                    horizontal: 22.0, vertical: 6.0),
                                decoration: BoxDecoration(
                                    color: Colors.blueAccent,
                                    borderRadius: BorderRadius.circular(20.0)),
                                child: AutoSizeText(listCard[i].getJobName().toString(),
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 25.0,
                                        fontFamily: "SF-Pro-Text-Regular")),
                              )
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12.0, bottom: 12.0),
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 22.0, vertical: 6.0),
                                decoration: BoxDecoration(
                                    color: Colors.blueAccent,
                                    borderRadius: BorderRadius.circular(20.0)),
                                child: Text("Tap to view",
                                    style: TextStyle(color: Colors.white)),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
          cardList.add(cardItem);
        }
        return Stack(
          children: cardList,
        );
      }),
    );
  }
}