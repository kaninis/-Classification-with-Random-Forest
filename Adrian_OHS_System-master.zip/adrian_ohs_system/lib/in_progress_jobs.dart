import 'dart:math';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/card_info_screen.dart';
import 'package:adrian_ohs_app/main.dart';
import 'package:adrian_ohs_app/res/arrays/data.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'in_progress_card_info.dart';
import 'login_page.dart';
import 'job_closure.dart';
import 'job_declining_ui.dart';
import 'res/graphql/graphQLMutations.dart';
import 'res/graphql/graphqlConf.dart';
import 'res/model/model_job_card.dart';


class InProgressJobs extends StatefulWidget {
  const InProgressJobs({Key key}) : super(key: key);
  @override
  _InProgressJobsState createState() => _InProgressJobsState();
}

var cardAspectRatio = 12.0 / 16.0;
var widgetAspectRatio = cardAspectRatio * 1.2;

GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();

List<JobCard> listCard = List<JobCard>();

QueryResult graphQueryResult;

//List<String> job_cards_list = new List();
//int job_cards_list_length;

class _InProgressJobsState extends State<InProgressJobs> {
  var currentPage = images.length - 1.0;
  int item_count;
  String job_id;

  var _result;
  @override
  void initState() {
    super.initState();
    fillList().then((result1){
      setState(() {
        _result = result1;
      });
    });
  }

  fillList() async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getAllTechnicianJobs("IN_PROGRESS"),
      ),
    );
    listCard.clear();
    if(graphQueryResult.data["technicianJobs"] != null) {
      if (!graphQueryResult.hasException) {
        for (var i = 0; i < graphQueryResult.data["technicianJobs"].length; i++) {
          setState(() {
            listCard.add(
              JobCard(
                graphQueryResult.data["technicianJobs"][i]["id"],
                graphQueryResult.data["technicianJobs"][i]["name"],
                graphQueryResult.data["technicianJobs"][i]["status"]["id"],
                graphQueryResult
                    .data["technicianJobs"][i]["scope"]["department"]["Name"],
                graphQueryResult
                    .data["technicianJobs"][i]["technician"]["Name"],
              ),
            );
          });
        }
        print(listCard.length.toString());
      }
      item_count = graphQueryResult.data["technicianJobs"].length;
//      print("JobID ");
//      print(graphQueryResult.data["technicianJobs"]["id"].toString());
//      job_id = graphQueryResult.data["technicianJobs"]["id"].toString();
    }
    return true;
  }

  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await Future.delayed(Duration(seconds: 2));

    Navigator.of(context).pushAndRemoveUntil(
      // the new route
      MaterialPageRoute(
        builder: (BuildContext context) => login(),
      ),
          (Route route) => false,
    );
  }
  void _showDialog() {
    // flutter defined function
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Center(child: Text('Fiber Installation Job Card')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  child: Text(
                    "message",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.red,
                    ),
                  ),
                ),
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      RaisedButton(
                        padding: const EdgeInsets.all(9.0),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage()));
                        },
                        color: Colors.blue[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: new Text(
                          "Accept",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),
                        ),
                      ),
                      RaisedButton(
                        padding: const EdgeInsets.all(9.0),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => Comments()));
                        },
                        color: Colors.blue[700],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: new Text(
                          "Decline",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),
                        ),
                      )
                    ])
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {

    PageController controller = PageController(initialPage: images.length - 1);
    controller.addListener(() {
      setState(() {
        currentPage = controller.page;
      });
    });

    if (_result == null) {
      // This is what we show while we're loading
      return new Container(
        color: Colors.white,
        child: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 300.0),
              Container(
                child: Image(image: new AssetImage("assets/adrian-loader.gif")),
                margin: const EdgeInsets.all(10.0),
                width: 120.0,
                height: 120.0,
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
                Color(0xffe92759),
                Color(0xFF141FAC),
              ],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              tileMode: TileMode.clamp)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(
                    left: 12.0, right: 12.0, top: 30.0, bottom: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    SizedBox(
                      height: 60.0,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text("Job Cards",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26.0,
                          fontFamily: "Calibre-Semibold",
                          letterSpacing: 1.0,
                        )),
                    IconButton(
                      icon: Icon(
                        Icons.graphic_eq,
                        size: 24.0,
                        color: Colors.white,
                      ),
                      onPressed: () {},
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0),
                child: Row(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFff6e6e),
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 22.0, vertical: 6.0),
                          child: Text("In Progress",
                              style: TextStyle(color: Colors.white)),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 15.0,
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  if(graphQueryResult.data["technicianJobs"].length != 0) {
//                    Navigator.push(
//                      context,
//                      MaterialPageRoute(
//                          builder: (context) =>
//                              job_closure(jobId: graphQueryResult
//                                  .data["technicianJobs"][currentPage.round()]["id"]
//                                  .toString(), jobStatusId: graphQueryResult
//                                  .data["technicianJobs"][currentPage.round()]["status"]["id"]
//                                  .toString(),)),
//                    );
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              CardInprogressInfoScreen(jobId: graphQueryResult
                                  .data["technicianJobs"][currentPage.round()]["id"]
                                  .toString())),
                    );
                  }
                },
                child: Stack(
                  children: <Widget>[
                    CardScrollWidget(currentPage),
                    Positioned.fill(
                      child: PageView.builder(
                        itemCount:item_count,
                        controller: controller,
                        reverse: true,
                        itemBuilder: (context, index) {
                          return Container();
                        },
                      ),
                    )
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

class CardScrollWidget extends StatelessWidget {
  var currentPage;
  var padding = 20.0;
  var verticalInset = 20.0;

  CardScrollWidget(this.currentPage);



  @override
  Widget build(BuildContext context) {

    return new AspectRatio(
      aspectRatio: widgetAspectRatio,
      child: LayoutBuilder(builder: (context, contraints) {
        var width = contraints.maxWidth;
        var height = contraints.maxHeight;

        var safeWidth = width - 2 * padding;
        var safeHeight = height - 2 * padding;

        var heightOfPrimaryCard = safeHeight;
        var widthOfPrimaryCard = heightOfPrimaryCard * cardAspectRatio;

        var primaryCardLeft = safeWidth - widthOfPrimaryCard;
        var horizontalInset = primaryCardLeft / 2;

        List<Widget> cardList = new List();

        for (var i = 0; i < listCard.length; i++) {
          var delta = i - currentPage;
          bool isOnRight = delta > 0;

          var start = padding +
              max(
                  primaryCardLeft -
                      horizontalInset * -delta * (isOnRight ? 15 : 1),
                  0.0);

          var cardItem = Positioned.directional(
            top: padding + verticalInset * max(-delta, 0.0),
            bottom: padding + verticalInset * max(-delta, 0.0),
            start: start,
            textDirection: TextDirection.rtl,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Container(
                decoration: BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.black12,
                      offset: Offset(3.0, 6.0),
                      blurRadius: 10.0)
                ]),
                child: AspectRatio(
                  aspectRatio: cardAspectRatio,
                  child: Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      Image.asset(images[0], fit: BoxFit.cover),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 8.0),
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 22.0, vertical: 6.0),
                                decoration: BoxDecoration(
                                    color: Colors.blueAccent,
                                    borderRadius: BorderRadius.circular(20.0)),
                                child: Container(
                                  width: MediaQuery.of(context).size.width/3,
                                  height: MediaQuery.of(context).size.height/15,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 22.0, vertical: 6.0),
                                  decoration: BoxDecoration(
                                      color: Colors.blueAccent,
                                      borderRadius: BorderRadius.circular(20.0)),
                                  child: AutoSizeText(listCard[i].getJobName().toString(),
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 25.0,
                                          fontFamily: "SF-Pro-Text-Regular")),
                                )
                              )
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12.0, bottom: 12.0),
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 22.0, vertical: 6.0),
                                decoration: BoxDecoration(
                                    color: Colors.blueAccent,
                                    borderRadius: BorderRadius.circular(20.0)),
                                child: Text("Tap To Close",
                                    style: TextStyle(color: Colors.white)),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
          cardList.add(cardItem);
        }
        return Stack(
          children: cardList,
        );
      }),
    );
  }
}