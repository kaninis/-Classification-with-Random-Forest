import 'dart:io';
import 'dart:math';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:adrian_ohs_app/safety_compliance.dart';
import 'package:adrian_ohs_app/home_page.dart';
import 'package:adrian_ohs_app/res/graphql/graphQLMutations.dart';
import 'package:adrian_ohs_app/res/graphql/graphqlConf.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toast/toast.dart';
import 'job_declining_ui.dart';
import 'navigation_home_screen.dart';
import 'res/model/model_job_card.dart';
import 'res/ui/app_theme.dart';

class CardApprovalInfoScreen extends StatefulWidget {
  final Color color1;
  final Color color2;
  final Color color3;

  final String jobId;

  CardApprovalInfoScreen(
      {Key key,
      @required this.jobId,
      this.color1 = Colors.deepOrangeAccent,
      this.color2 = Colors.deepPurple,
      this.color3 = Colors.lightGreen})
      : super(key: key);
  @override
  _CardApprovalInfoScreenState createState() =>
      _CardApprovalInfoScreenState(JobId: jobId);
}

class _CardApprovalInfoScreenState extends State<CardApprovalInfoScreen>
    with TickerProviderStateMixin {
  final String JobId;
  HomePage homePage = HomePage();
  final double infoHeight = 364.0;
  AnimationController animationController;
  Animation<double> animation;
  double opacity1 = 0.0;
  double opacity2 = 0.0;
  double opacity3 = 0.0;

  var jobIdToRejectComments;

  String JobStatusId,
      JobStatusType,
      JobDepartment,
      JobName,
//      JobHazardRiskLevel,
      JobScopeName,
//      JobActivity,
      induction,
      ppe,
      toolboxtalk,
      extinguisher,
      first_aid,
      location_name;
  String JobApprovalResponse1 = "";
  String JobApprovalResponse2 = "";
  String JobApprovalResponse3 = "";
  String JobApprovalResponse4 = "";
  String Hazardss = "";

  List<String> HazardLists = [];
  List<String> Controls = [];
  List<String> HazarIDdLists = [];
  List<String> HazardControlsLists = [];
  List<String> DocumentsList = [];
  List<Map<String, String>> IncidentReportList = [];
  Map<String, String> CreateHazardMap = {};
  int documents_length, hazards_length;

  var _result;

  _CardApprovalInfoScreenState({Key key, @required this.JobId});

  @override
  void initState() {
    animationController = AnimationController(
        duration: const Duration(milliseconds: 1000), vsync: this);
    animation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0, 1.0, curve: Curves.fastOutSlowIn)));
    setData();
    print("length :$HazardLists");
    super.initState();
    getJobCardDetails(JobId).then((result1) {
      setState(() {
        _result = result1;
      });
    });

    print("JobId: " + JobId.toString());
    jobIdToRejectComments = JobId;
  }

  getControls(String hazard_id) async{
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
    QueryOptions(
        document: queryMutation.getControls(hazard_id),
    ));
     if (!graphQueryResult.hasException) {
         await HazardControlsLists.clear();
         for (int c = 0; c <graphQueryResult.data["hazard"]["controls"].length; c++) {
           String control_name = await graphQueryResult.data["hazard"]["controls"][c]["text"];
           String final_control_name = control_name + await graphQueryResult.data["hazard"]["controls"][c++]["text"];

              await HazardControlsLists.add(control_name);
               print ("Control name: $control_name");
               print(graphQueryResult.data["hazard"]["controls"].length);

                 }
         SharedPreferences sharedpreference = await SharedPreferences.getInstance();
         await sharedpreference.setStringList("controls", HazardControlsLists);
         print(HazardControlsLists);
     }
  }
  getJobCardDetails(String jobId) async {
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    graphQueryResult = await _client.query(
      QueryOptions(
        document: queryMutation.getASingleJobDetails(jobId),
      ),
    );
    if (!graphQueryResult.hasException) {
      JobName = graphQueryResult.data["job"]["name"];
      JobStatusId = graphQueryResult.data["job"]["status"]["id"];
      JobStatusType = graphQueryResult.data["job"]["status"]["type"];
      JobDepartment = graphQueryResult.data["job"]["scope"]["department"]["division"]["name"];
//      JobHazardRiskLevel = graphQueryResult.data["job"]["scope"]["hazard"];
      JobScopeName = graphQueryResult.data["job"]["scope"]["name"];
      location_name = graphQueryResult.data["job"]["location_name"];
//      JobActivity = graphQueryResult.data["job"]["scope"]["activity"];
      ppe = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["ppe"]
          : "null";
      first_aid = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["first_aid"]
          : "null";
      extinguisher = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["extinguisher"]
          : "null";
      induction = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["induction"]
          : "null";
      documents_length =
          graphQueryResult.data["job"]["compliance"]["documents"].length;
      toolboxtalk = graphQueryResult.data["job"]["compliance"] != null
          ? graphQueryResult.data["job"]["compliance"]["toolbox"]
          : "null";
      JobScopeName = graphQueryResult.data["job"]["scope"]["name"];
      JobApprovalResponse1 =
          graphQueryResult.data["job"]["lv1_approval"] != null
              ? graphQueryResult.data["job"]["lv1_approval"]["reason"]
              : "null";
      JobApprovalResponse2 =
          graphQueryResult.data["job"]["lv2_approval"] != null
              ? graphQueryResult.data["job"]["lv2_approval"]["reason"]
              : "null";
      JobApprovalResponse3 =
          graphQueryResult.data["job"]["lv3_approval"] != null
              ? graphQueryResult.data["job"]["lv3_approval"]["reason"]
              : "null";
      JobApprovalResponse4 =
          graphQueryResult.data["job"]["lv4_approval"] != null
              ? graphQueryResult.data["job"]["lv4_approval"]["reason"]
              : "null";

      for (int a = 0;
          a < graphQueryResult.data["job"]["compliance"]["documents"].length;
          a++) {
        String document_name = graphQueryResult.data["job"]["compliance"]
                ["documents"][a]["name"]
            .toString();
        print("document_name: " + document_name);
        DocumentsList.add(document_name);
      }

      for (int b = 0;
          b < graphQueryResult.data["job"]["compliance"]["jha"].length;
          b++) {
        String hazard_name = graphQueryResult.data["job"]["compliance"]["jha"]
                [b]["text"]
            .toString();
        String hazard_id = graphQueryResult.data["job"]["compliance"]["jha"][b]
                ["id"]
            .toString();
        print("hazard_name: " + hazard_name);
        HazarIDdLists.add(hazard_id);
        HazardLists.add(hazard_name);
      }
      for (int a = 0; a < graphQueryResult.data["job"]["closure"].length; a++) {
        String incident_name = graphQueryResult.data["job"]["closure"][a]
                ["closuretype"]["name"]
            .toString();
        String incident_number =
            graphQueryResult.data["job"]["closure"][a]["amount"].toString();
        Map<String, String> CreateMap = {};
        CreateMap["Incident"] = incident_name;
        CreateMap["Number"] = incident_number;
        IncidentReportList.add(CreateMap);
        print("document_name: " + incident_name);
//        IncidentReportList.add(incident_name);
      }
      print("Status Id: " + JobStatusId.toString());
      print("Job Name : " + JobName.toString());
      print("Status Name: " + JobStatusType.toString());
//      print("Activities : " + JobActivity.toString());
      print("Reason 1 : " + JobApprovalResponse1.toString());
      print("Reason 2 : " + JobApprovalResponse2.toString());
      print("Reason 3 : " + JobApprovalResponse3.toString());
      print("List : " +
          graphQueryResult.data["job"]["compliance"]["documents"][0]["name"]
              .toString());
      print("List jha : " +
          graphQueryResult.data["job"]["compliance"]["jha"][0]["controls"][0]
                  ["text"]
              .toString());
    }
    return true;
  }

  void changeJobStatusAccept() async {
    String jobStatusId = JobStatusId;
    String jobStatus = "PENDING";
    GraphQLConfiguration graphQLConfiguration = GraphQLConfiguration();
    QueryMutation queryMutation = QueryMutation();
    GraphQLClient _client = graphQLConfiguration.clientToQuery();
    QueryResult result = await _client.mutate(
      MutationOptions(
        document:
            queryMutation.changeJobCardStatus(jobStatusId, jobStatus, null),
      ),
    );
    if (result.hasException) {
      Toast.show("data has errors", context);
    } else {
      Toast.show("Job card accepted", context);
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => safetyCompliance(jobId: JobId)));
//      Navigator.push(context, MaterialPageRoute(builder: (context) => FilePickerDemo()));
    }
  }

  Future<void> setData() async {
    animationController.forward();
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity1 = 1.0;
    });
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity2 = 1.0;
    });
    await Future<dynamic>.delayed(const Duration(milliseconds: 200));
    setState(() {
      opacity3 = 1.0;
    });
  }
  void _showDialog() {
    // flutter defined function
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Colors.transparent,
            title: Center(
                child: Text('Controls', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
//            contentPadding: const EdgeInsets.all(19.0),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                SingleChildScrollView(
                  child: Container(
                      decoration: BoxDecoration(
                        color: AppTheme.white,
                        borderRadius: const BorderRadius.all(Radius.circular(16.0)),
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                              color: AppTheme.grey.withOpacity(0.2),
                              offset: const Offset(1.1, 1.1),
                              blurRadius: 8.0),
                        ],
                      ),
                      height: MediaQuery.of(context).size.height/2,
                      child: ListView
                          .builder(
                          scrollDirection: Axis
                              .vertical,
                          shrinkWrap:
                          true,
                          itemCount: HazardControlsLists.length,
                          itemBuilder:
                              (context, index) {
//                            Toast.show(HazardControlsLists.length.toString(), context);
                            return ListTile(
                              title: Text(
                                HazardControlsLists[index],
                              ),
                            );
                          })),
                ),
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      RaisedButton(
//                        padding: const EdgeInsets.all(9.0),
                        onPressed: (){
                          Navigator.pop(context);
                        },
                        color: AppTheme.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)),
                        child: new Text(
                          "Ok",
                          style: TextStyle(
                              fontSize: 20,
                              color: AppTheme.mainNavyBlue
                          ),
                        ),
                      ),
                    ])
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    final double tempHeight = MediaQuery.of(context).size.height -
        (MediaQuery.of(context).size.width / 1.2) +
        24.0;
    if (_result == null) {
      // This is what we show while we're loading
      return new Container(
        color: Colors.white,
        child: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 300.0),
              Container(
                child: Image(image: new AssetImage("assets/adrian-loader.gif")),
                margin: const EdgeInsets.all(10.0),
                width: 120.0,
                height: 120.0,
              ),
            ],
          ),
        ),
      );
    }

    return new WillPopScope(
      onWillPop: _onWillPop,
      child: Container(
        color: AppTheme.nearlyWhite,
        child: Scaffold(
          resizeToAvoidBottomPadding: false,
          backgroundColor: Colors.transparent,
          body: Container(
            child: Column(
              children: <Widget>[
                Container(
                  height: MediaQuery.of(context).size.height,
                  child: Stack(
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          AspectRatio(
                            aspectRatio: 1.0,
                            child: Container(
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomLeft,
                                      colors: [
                                    AppTheme.mainNavyBlue,
                                    AppTheme.mainPink
                                  ])),
                            ),
                          ),
                        ],
                      ),
                      Positioned(
                        top: (MediaQuery.of(context).size.width / 2.5) - 24.0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppTheme.nearlyWhite,
                            borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(32.0),
                                topRight: Radius.circular(32.0)),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                  color: AppTheme.grey.withOpacity(0.2),
                                  offset: const Offset(1.1, 1.1),
                                  blurRadius: 10.0),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8, right: 8),
                            child: SingleChildScrollView(
                              child: Container(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16,
                                          right: 16,
                                          bottom: 8,
                                          top: 16),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2,
                                            child: Text(
                                              'Scope of work: ',
                                              maxLines: 4,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w200,
                                                fontSize: 20,
                                                letterSpacing: 0.27,
                                                color: AppTheme.nearlyBlack,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                3,
                                            child: AutoSizeText(
                                              JobScopeName,
                                              maxLines: 4,
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w400,
                                                fontSize: 22,
                                                letterSpacing: 0.27,
                                                color: AppTheme.mainNavyBlue,
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    AnimatedOpacity(
                                      duration:
                                          const Duration(milliseconds: 500),
                                      opacity: opacity1,
                                      child: Padding(
                                        padding: const EdgeInsets.all(3),
                                        child: Row(
                                          children: <Widget>[
                                            getTimeBoxUI(
                                                JobStatusType, 'Status'),
//                                            getTimeBoxUI(JobHazardRiskLevel,
//                                                'Risk level'),
                                            getTimeBoxUI(
                                                JobDepartment, 'Department'),
                                          ],
                                        ),
                                      ),
                                    ),
                                    ExpansionTile(
                                      title: Text(
                                        "Location",
                                        maxLines: 4,
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w200,
                                          fontSize: 20,
                                          letterSpacing: 0.27,
                                          color: AppTheme.nearlyBlack,
                                        ),
                                      ),
                                      children: <Widget>[
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              2,
                                          child: Text(
                                            location_name,
                                            maxLines: 4,
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              letterSpacing: 0.27,
                                              color: AppTheme.mainNavyBlue,
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
//                                    AnimatedOpacity(
//                                      duration:
//                                          const Duration(milliseconds: 500),
//                                      opacity: opacity2,
//                                      child: Padding(
//                                        padding: const EdgeInsets.only(
//                                            left: 16,
//                                            right: 16,
//                                            top: 8,
//                                            bottom: 8),
//                                        child: Text(
//                                          JobActivity,
//                                          textAlign: TextAlign.justify,
//                                          style: TextStyle(
//                                            fontWeight: FontWeight.w300,
//                                            fontSize: 14,
//                                            letterSpacing: 0.27,
//                                            color: AppTheme.grey,
//                                          ),
//                                          maxLines: 3,
//                                          overflow: TextOverflow.ellipsis,
//                                        ),
//                                      ),
//                                    ),
                                    ExpansionTile(
                                      title: Text(
                                        "Safety Compliance Assesment",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w200,
                                          fontSize: 20,
                                          letterSpacing: 0.27,
                                          color: AppTheme.nearlyBlack,
                                        ),
                                      ),
                                      children: <Widget>[
                                        ExpansionTile(
                                          title: Text('Photo Uploads'),
                                          children: <Widget>[
                                            Column(
                                              children: <Widget>[
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                    Column(
                                                      children: <Widget>[
                                                        Text(
                                                            "Personnel PPE Image"),
                                                        Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width /
                                                              3,
                                                          child: ppe == null
                                                              ? Container(
                                                                  width: 180.0,
                                                                  height: 270.0,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius.all(
                                                                            Radius.circular(8.0)),
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                  child: Center(
                                                                      child:
                                                                          Column(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .center,
                                                                    children: <
                                                                        Widget>[
                                                                      Text(
                                                                        'No image',
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                20,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color: Colors.grey),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                      ),
                                                                    ],
                                                                  )),
                                                                )
                                                              : Container(
                                                                  width: 160.0,
                                                                  height: 240.0,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius.all(
                                                                            Radius.circular(8.0)),
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                  child: Image
                                                                      .network(
                                                                    ppe,
                                                                    height:
                                                                        150.0,
                                                                    width:
                                                                        100.0,
                                                                  ),
                                                                ),
//              Image.file(ppe),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      children: <Widget>[
                                                        Text(
                                                            "First-aid Kit Image"),
                                                        Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width /
                                                              3,
                                                          child:
                                                              first_aid == null
                                                                  ? Container(
                                                                      width:
                                                                          180.0,
                                                                      height:
                                                                          270.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Center(
                                                                          child: Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.center,
                                                                        children: <
                                                                            Widget>[
                                                                          Text(
                                                                            'No image',
                                                                            style: TextStyle(
                                                                                fontSize: 20,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ],
                                                                      )),
                                                                    )
                                                                  : Container(
                                                                      width:
                                                                          160.0,
                                                                      height:
                                                                          240.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Image
                                                                          .network(
                                                                        first_aid,
                                                                        height:
                                                                            150.0,
                                                                        width:
                                                                            100.0,
                                                                      ),
                                                                    ),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Column(
                                              children: <Widget>[
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                    Column(
                                                      children: <Widget>[
                                                        Text(
                                                            "Fire Extinguisher Image"),
                                                        Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width /
                                                              3,
                                                          child:
                                                              extinguisher ==
                                                                      null
                                                                  ? Container(
                                                                      width:
                                                                          180.0,
                                                                      height:
                                                                          270.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Center(
                                                                          child: Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.center,
                                                                        children: <
                                                                            Widget>[
                                                                          Text(
                                                                            'No image',
                                                                            style: TextStyle(
                                                                                fontSize: 20,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ],
                                                                      )),
                                                                    )
                                                                  : Container(
                                                                      width:
                                                                          160.0,
                                                                      height:
                                                                          240.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Image
                                                                          .network(
                                                                        extinguisher,
                                                                        height:
                                                                            150.0,
                                                                        width:
                                                                            100.0,
                                                                      ),
                                                                    ),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      children: <Widget>[
                                                        Text(
                                                            "Induction Form Image"),
                                                        Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width /
                                                              3,
                                                          child:
                                                              induction == null
                                                                  ? Container(
                                                                      width:
                                                                          180.0,
                                                                      height:
                                                                          270.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Center(
                                                                          child: Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.center,
                                                                        children: <
                                                                            Widget>[
                                                                          Text(
                                                                            'No image',
                                                                            style: TextStyle(
                                                                                fontSize: 20,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ],
                                                                      )),
                                                                    )
                                                                  : Container(
                                                                      width:
                                                                          160.0,
                                                                      height:
                                                                          240.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Image
                                                                          .network(
                                                                        induction,
                                                                        height:
                                                                            150.0,
                                                                        width:
                                                                            100.0,
                                                                      ),
                                                                    ),
//              Image.file(ppe),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Column(
                                              children: <Widget>[
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                    Column(
                                                      children: <Widget>[
                                                        Text(
                                                            "Toolboxtalk Form Image"),
                                                        Container(
                                                          width: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width /
                                                              3,
                                                          child:
                                                              toolboxtalk ==
                                                                      null
                                                                  ? Container(
                                                                      width:
                                                                          180.0,
                                                                      height:
                                                                          270.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Center(
                                                                          child: Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.center,
                                                                        children: <
                                                                            Widget>[
                                                                          Text(
                                                                            'No image',
                                                                            style: TextStyle(
                                                                                fontSize: 20,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey),
                                                                            textAlign:
                                                                                TextAlign.center,
                                                                          ),
                                                                        ],
                                                                      )),
                                                                    )
                                                                  : Container(
                                                                      width:
                                                                          160.0,
                                                                      height:
                                                                          240.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(8.0)),
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child: Image
                                                                          .network(
                                                                        toolboxtalk,
                                                                        height:
                                                                            150.0,
                                                                        width:
                                                                            100.0,
                                                                      ),
                                                                    ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        ExpansionTile(
                                          title: Text('Job Hazard Analysis'),
                                          children: <Widget>[
//                                            Container(
//                                                child: SingleChildScrollView(
//                                              child: Column(
//                                                children: <Widget>[
//                                                  Container(
//                                                    height: 350,
//                                                    child: ListView.builder(
//                                                      scrollDirection:
//                                                          Axis.vertical,
//                                                      shrinkWrap: true,
//                                                      itemCount:
//                                                          HazardLists.length,
//                                                      itemBuilder:
//                                                          (context, int index) {
//                                                        return ExpansionTile(
//                                                          onExpansionChanged:
//                                                              (expanded) async{
//                                                                String id = await HazarIDdLists[index];
//                                                                await getControls(id);
//                                                                SharedPreferences sharedpreference = await SharedPreferences.getInstance();
//                                                                Controls = sharedpreference.getStringList('controls');
//                                                                print (Controls);
//                                                              print(id);
//                                                              Toast.show(
//                                                                  "I have been expanded" +
//                                                                      id,
//                                                                  context);
//                                                          },
//                                                          title: Text(
//                                                              HazardLists[
//                                                                  index],
//                                                              style: TextStyle(
//                                                                fontSize: 15.0,
//                                                                fontFamily:
//                                                                    "Calibre-Semibold",
//                                                                letterSpacing:
//                                                                    1.0,
//                                                              )),
//                                                          children: <Widget>[
//                                                            SingleChildScrollView(
//                                                              child: Container(
//                                                                  height: 200,
//                                                                  child: ListView
//                                                                      .builder(
//                                                                          scrollDirection: Axis
//                                                                              .vertical,
//                                                                          shrinkWrap:
//                                                                              true,
//                                                                          itemCount: HazardControlsLists
//                                                                                    .length,
//                                                                          itemBuilder:
//                                                                              (context, index) {
//                                                                            Toast.show(HazardControlsLists.length.toString(), context);
//                                                                            return ListTile(
//                                                                              title: Text(
//                                                                                HazardControlsLists[index],
//                                                                              ),
//                                                                            );
//                                                                          })),
//                                                            ),
//                                                          ],
//                                                        );
//                                                      },
//                                                    ),
//                                                  ),
//                                                ],
//                                              ),
//                                            )),
                                            ListView.builder(
                                                scrollDirection: Axis.vertical,
                                                shrinkWrap: true,
                                                itemCount: HazardLists.length,
                                                itemBuilder: (context, index) {
                                                  return Card(
                                                    child: Row(
                                                      children: <Widget>[
                                                        Flexible(
                                                          child: ListTile(
                                                            title: Text(
                                                                HazardLists[
                                                                        index]
                                                                    .toString()),
                                                            trailing: RaisedButton(
                                                               child: Text("View Controls"),
                                                                onPressed: ()
                                                            async{
                                                              String id = await HazarIDdLists[index];
                                                              await getControls(id);
                                                              _showDialog();
                                                            }),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                }),
                                          ],
                                        ),
                                        ExpansionTile(
                                          title: Text(
                                            'Documents used Confirmation',
                                          ),
                                          children: <Widget>[
                                            ListView.builder(
                                                scrollDirection: Axis.vertical,
                                                shrinkWrap: true,
                                                itemCount: DocumentsList.length,
                                                itemBuilder: (context, index) {
                                                  return Card(
                                                    child: Row(
                                                      children: <Widget>[
                                                        Flexible(
                                                          child: ListTile(
                                                            title: Text(
                                                                DocumentsList[
                                                                        index]
                                                                    .toString()),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                }),
                                          ],
                                        ),
                                      ],
                                    ),
                                    AnimatedOpacity(
                                      duration:
                                          const Duration(milliseconds: 500),
                                      opacity: opacity1,
                                      child: Padding(
                                          padding: const EdgeInsets.all(3),
                                          child: Wrap(
//                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              getTimeBoxUI('Approval Level 1',
                                                  JobApprovalResponse1),
                                              getTimeBoxUI('Approval Level 2',
                                                  JobApprovalResponse2),
                                              getTimeBoxUI('Approval Level 3',
                                                  JobApprovalResponse3),
                                              getTimeBoxUI('Approval Level 4',
                                                  JobApprovalResponse4),
                                            ],
                                          )),
                                    ),
                                    ExpansionTile(
                                      title: Text(
                                        "Incident Report",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w200,
                                          fontSize: 20,
                                          letterSpacing: 0.27,
                                          color: AppTheme.nearlyBlack,
                                        ),
                                      ),
                                      children: <Widget>[
                                        DataTable(
                                          columns: [
                                            DataColumn(label: Text('Incident')),
                                            DataColumn(label: Text('Number')),
                                          ],
                                          rows: IncidentReportList.map(
                                              ((element) =>
                                                  DataRow(cells: <DataCell>[
                                                    DataCell(
                                                      Text(element['Incident']),
                                                    ),
                                                    DataCell(
                                                      Text(element['Number']),
                                                    )
                                                  ]))).toList(),
                                        ),
                                      ],
                                    ),
                                    AnimatedOpacity(
                                      duration:
                                          const Duration(milliseconds: 500),
                                      opacity: opacity3,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, bottom: 16, right: 16),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Container(
                                              width: 48,
                                              height: 48,
                                              child: GestureDetector(
                                                onTap: () {
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              NavigationHomeScreen()));
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: AppTheme.nearlyWhite,
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                      Radius.circular(16.0),
                                                    ),
                                                    border: Border.all(
                                                        color: AppTheme.grey
                                                            .withOpacity(0.2)),
                                                  ),
                                                  child: Icon(
                                                    Icons.arrow_back_ios,
                                                    color:
                                                        AppTheme.mainNavyBlue,
                                                    size: 28,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 16,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).padding.bottom,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        top: (MediaQuery.of(context).size.width / 2.59) -
                            24.0 -
                            35,
                        right: 35,
                        child: ScaleTransition(
                          alignment: Alignment.center,
                          scale: CurvedAnimation(
                              parent: animationController,
                              curve: Curves.fastOutSlowIn),
                          child: Card(
                            color: AppTheme.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50.0)),
                            elevation: 10.0,
                            child: Container(
                              width: 60,
                              height: 60,
                              child: Center(
                                child: Container(
                                  child: Image(
                                      image:
                                          new AssetImage("assets/Arplogo.png")),
                                  width: 40.0,
                                  height: 40.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: MediaQuery.of(context).padding.top),
                        child: Container(
                          width: MediaQuery.of(context).size.width,
                          height: AppBar().preferredSize.height,
                          child: Material(
                              color: Colors.transparent,
                              child: Row(
                                children: <Widget>[
                                  InkWell(
                                    borderRadius: BorderRadius.circular(
                                        AppBar().preferredSize.height),
                                    child: Icon(
                                      Icons.arrow_back_ios,
                                      color: Colors.white,
                                    ),
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                NavigationHomeScreen()),
                                      );
                                    },
                                  ),
                                  SizedBox(
                                      width: MediaQuery.of(context).size.width /
                                          2.9),
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width / 2,
                                    child: AutoSizeText(
                                      JobName,
                                      maxLines: 8,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 22,
                                        letterSpacing: 0.27,
                                        color: Colors.white,
                                      ),
                                    ),
                                  )
                                ],
                              )),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget getTimeBoxUI(String text1, String txt2) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        constraints:
            new BoxConstraints(maxWidth: MediaQuery.of(context).size.width / 4),
        decoration: BoxDecoration(
          color: AppTheme.nearlyWhite,
          borderRadius: const BorderRadius.all(Radius.circular(16.0)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: AppTheme.grey.withOpacity(0.2),
                offset: const Offset(1.1, 1.1),
                blurRadius: 8.0),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.only(
              left: 9.0, right: 9.0, top: 12.0, bottom: 12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              AutoSizeText(
                text1,
                maxLines: 4,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                  letterSpacing: 0.27,
                  color: AppTheme.mainNavyBlue,
                ),
              ),
              Text(
                txt2,
                maxLines: 5,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w200,
                  fontSize: 11,
                  letterSpacing: 0.27,
                  color: AppTheme.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _onWillPop() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NavigationHomeScreen()),
//                        builder: (context) => CardApprovalInfoScreen(jobId: currentPage.round().toString())),
    );
  }
}
