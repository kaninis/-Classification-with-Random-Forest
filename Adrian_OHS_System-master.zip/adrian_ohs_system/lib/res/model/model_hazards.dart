class hazards {
  hazards(this.id, this.text, this.consequence);

  final String id;
  final String text;
  final String consequence;
//  final List<String> controls;



  getJobId() => this.id;

  getJobHazard()  => this.text;

  getConsequence() => this.consequence;

//  getControls() => this.controls;


}